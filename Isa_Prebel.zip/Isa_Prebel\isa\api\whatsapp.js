// Webhook de WhatsApp Cloud API → mismo cerebro de Isa que la web.
//   GET  /api/whatsapp   verificación del webhook (Meta)
//   POST /api/whatsapp   mensajes entrantes
import crypto from "node:crypto";
import { waitUntil } from "@vercel/functions";
import { responder, separarCierre, validar, etiquetasFuentes, respuestaLiteral as textoOficial, hayClave, TIPOS, SEDES, NO_INFO } from "../lib/isa.js";
import { respuestaLiteral } from "../lib/literal.js";
import { leerSesion, guardarSesion, yaProcesado } from "../lib/estado.js";
import { enviarTexto, enviarBotones, enviarLista, aWhatsApp } from "../lib/canal-whatsapp.js";

const BOTONES_TIPO = [
  { id: "tipo:operativo", titulo: "Operativo" },
  { id: "tipo:impulso", titulo: "Impulso y mercado" },
  { id: "tipo:administrativo", titulo: "Administrativo" },
];
const FILAS_SEDE = [
  { id: "sede:productora", titulo: "Sede Productora" },
  { id: "sede:rionegro", titulo: "Sede Rionegro" },
  { id: "sede:comercial", titulo: "Sede Comercial" },
  { id: "sede:fuera", titulo: "Fuera de sede" },
  { id: "sede:nose", titulo: "Prefiero no decir" },
];

// El botón de la web abre WhatsApp con un texto como "Hola Isa, soy operativo de Sede Productora".
export function detectarPerfil(t) {
  const n = t.normalize("NFD").replace(/[̀-ͯ]/g, "").toLowerCase();
  const p = {};
  if (/operativ/.test(n)) p.tipo = "operativo";
  else if (/impul?s|mercad/.test(n)) p.tipo = "impulso";
  else if (/administrativ/.test(n)) p.tipo = "administrativo";
  if (/productora/.test(n)) p.sede = "productora";
  else if (/rionegro/.test(n)) p.sede = "rionegro";
  else if (/comercial/.test(n)) p.sede = "comercial";
  else if (/fuera de sede/.test(n)) p.sede = "fuera";
  return p;
}
const esSaludo = (t) => /^\s*(hola|buen[oa]s?( dias| días| tardes| noches)?|hey|holi|menu|menú|inicio)\b[^?]{0,60}$/i.test(t);
const pideCambioPerfil = (t) => /^\s*(cambiar perfil|perfil|reiniciar)\s*$/i.test(t);

async function leerCrudo(req) {
  const partes = [];
  for await (const p of req) partes.push(p);
  return Buffer.concat(partes);
}

function firmaValida(req, crudo) {
  const secreto = process.env.WA_APP_SECRET;
  if (!secreto) return true; // en pruebas locales; en producción debe estar configurado
  const firma = String(req.headers["x-hub-signature-256"] || "");
  const esperada = "sha256=" + crypto.createHmac("sha256", secreto).update(crudo).digest("hex");
  return firma.length === esperada.length && crypto.timingSafeEqual(Buffer.from(firma), Buffer.from(esperada));
}

async function contestar(wa, pregunta, s) {
  let texto;
  if (hayClave()) {
    try {
      const r = await responder({ historial: s.historial, pregunta, perfil: s.perfil }, () => {});
      if (r.rechazo) texto = NO_INFO;
      else {
        const c = separarCierre(r.bruto);
        const v = validar(c.texto, c.fuentes);
        texto = aWhatsApp(v.valido ? c.texto : textoOficial(c.fuentes));
        const f = etiquetasFuentes(c.fuentes).map((x) => x.etiqueta.split(" › ").slice(0, 2).join(" › "));
        if (f.length) texto += `\n\n📄 _Fuente: ${[...new Set(f)].join("; ")}_`;
        if (c.sugerencias.length) texto += `\n\n💬 También puedes preguntarme:\n${c.sugerencias.map((x) => "• " + x).join("\n")}`;
        s.historial.push({ rol: "user", texto: pregunta }, { rol: "assistant", texto: c.texto });
      }
    } catch (e) {
      console.error("[isa wa] Claude falló, uso motor literal", e?.status || e?.message);
    }
  }
  if (!texto) {
    const a = respuestaLiteral(pregunta, s.perfil.tipo);
    texto = (a.aviso ? `⚠️ ${a.aviso}\n\n` : "") + a.texto;
  }
  await enviarTexto(wa, texto);
}

async function procesar(m) {
  if (await yaProcesado(m.id)) return;
  const wa = m.from;
  const s = await leerSesion(wa);
  s.perfil ||= {};
  s.historial ||= [];

  if (m.type === "audio") {
    await enviarTexto(wa, "🎙️ Por ahora no puedo escuchar notas de voz. Escríbeme tu pregunta y te respondo de una.");
    return;
  }
  let texto = m.type === "text" ? m.text.body.trim() : "";
  const elegido = m.type === "interactive" ? (m.interactive.button_reply || m.interactive.list_reply)?.id : null;

  if (elegido?.startsWith("tipo:")) s.perfil.tipo = elegido.slice(5);
  else if (elegido?.startsWith("sede:")) s.perfil.sede = elegido.slice(5);
  else if (texto && pideCambioPerfil(texto)) { s.perfil = {}; texto = ""; }
  else if (texto) {
    const p = detectarPerfil(texto);
    if (!s.perfil.tipo && p.tipo) s.perfil.tipo = p.tipo;
    if (!s.perfil.sede && p.sede) s.perfil.sede = p.sede;
    if (!esSaludo(texto) && !/^hola isa, soy/i.test(texto)) s.pendiente = texto; // pregunta real: se responde cuando haya perfil
  } else if (!elegido) {
    await enviarTexto(wa, "Por ahora entiendo mensajes de texto. ¿Qué quieres consultar?");
    return;
  }

  // Perfil en dos toques (una sola vez por persona).
  if (!s.perfil.tipo) {
    await guardarSesion(wa, s);
    await enviarBotones(wa, "¡Hola! Soy *Isa*, de Gestión Humana de Prebel 👋\n\nPara darte la respuesta que te corresponde: ¿cómo trabajas en Prebel?", BOTONES_TIPO);
    return;
  }
  if (!s.perfil.sede) {
    await guardarSesion(wa, s);
    await enviarLista(wa, "¿En qué sede estás?", "Elegir sede", FILAS_SEDE);
    return;
  }

  const pregunta = s.pendiente;
  s.pendiente = null;
  if (!pregunta) {
    await guardarSesion(wa, s);
    await enviarTexto(wa, `Listo ✅ ${TIPOS[s.perfil.tipo]}${s.perfil.sede !== "nose" ? " · " + SEDES[s.perfil.sede] : ""}.\n\n¿Qué quieres consultar? Por ejemplo: certificados, cesantías, vacaciones, créditos o auxilios.\n\n_Isa usa IA y puede equivocarse. Escribe *perfil* para cambiar tus datos._`);
    return;
  }
  await contestar(wa, pregunta, s);
  await guardarSesion(wa, s);
}

export default async function handler(req, res) {
  if (req.method === "GET") {
    const q = new URL(req.url, "http://x").searchParams;
    if (q.get("hub.mode") === "subscribe" && q.get("hub.verify_token") && q.get("hub.verify_token") === process.env.WA_VERIFY_TOKEN) {
      res.statusCode = 200;
      return res.end(q.get("hub.challenge"));
    }
    res.statusCode = 403;
    return res.end();
  }
  if (req.method !== "POST") { res.statusCode = 405; return res.end(); }

  const crudo = await leerCrudo(req);
  if (!firmaValida(req, crudo)) { res.statusCode = 401; return res.end(); }
  let cuerpo;
  try { cuerpo = JSON.parse(crudo.toString("utf8")); } catch { res.statusCode = 400; return res.end(); }

  const mensajes = (cuerpo.entry || []).flatMap((e) => (e.changes || []).flatMap((c) => c.value?.messages || []));
  const trabajo = Promise.all(mensajes.map((m) => procesar(m).catch((e) => console.error("[isa wa]", e))));
  // Meta necesita un 200 rápido; la respuesta a la persona se termina en segundo plano.
  waitUntil(trabajo);
  res.statusCode = 200;
  res.end("ok");
  if (process.env.ISA_LOCAL) await trabajo; // en el servidor local se espera para ver errores
}
