// Servidor local: sirve public/ y enruta /api/chat al mismo handler que usa Vercel.
// Uso: npm run dev   (lee la API key de .env.local si existe)
import http from "node:http";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const envFile = path.join(root, ".env.local");
if (fs.existsSync(envFile)) {
  for (const linea of fs.readFileSync(envFile, "utf8").split(/\r?\n/)) {
    const m = linea.match(/^\s*([A-Z0-9_]+)\s*=\s*(.*)\s*$/);
    if (m && !process.env[m[1]]) process.env[m[1]] = m[2].replace(/^["']|["']$/g, "");
  }
}
process.env.ISA_LOCAL = "1";
const api = {
  "/api/chat": (await import("../api/chat.js")).default,
  "/api/whatsapp": (await import("../api/whatsapp.js")).default,
};

const TIPOS = { ".html": "text/html; charset=utf-8", ".css": "text/css", ".js": "text/javascript", ".json": "application/json", ".svg": "image/svg+xml", ".png": "image/png", ".otf": "font/otf", ".ico": "image/x-icon" };
const pub = path.join(root, "public");
const port = Number(process.env.PORT || 5173);

http
  .createServer(async (req, res) => {
    const url = new URL(req.url, "http://x");
    if (api[url.pathname]) return api[url.pathname](req, res);
    let f = path.normalize(path.join(pub, decodeURIComponent(url.pathname)));
    if (!f.startsWith(pub)) return res.writeHead(403).end();
    if (fs.existsSync(f) && fs.statSync(f).isDirectory()) f = path.join(f, "index.html");
    if (!fs.existsSync(f)) return res.writeHead(404).end("No encontrado");
    res.writeHead(200, { "content-type": TIPOS[path.extname(f)] || "application/octet-stream" });
    fs.createReadStream(f).pipe(res);
  })
  .listen(port, () => console.log(`Isa en http://localhost:${port}  (IA: ${process.env.ANTHROPIC_API_KEY ? "Claude" : "sin clave → modo literal"})`));
