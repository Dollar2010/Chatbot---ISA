# Base de conocimiento de Isa

Generada desde los documentos oficiales de Gestión Humana (secciones parseadas por Valentina). 116 secciones con identificador para citar.

## Vinculación y nómina (Vinculacion_y_nomina_20260310.md, 10/03/2026)

### [VIN-01] 1. Certificados laborales › 1.1 Personal operativo

Por favor relacionar los siguientes datos: nombre completo, número de cédula de ciudadanía, correo electrónico, celular y entidad o persona a la que va dirigido el certificado.

Nota: El certificado laboral no puede ir dirigido a quien pueda interesar.

Encargada: Angela Quintero

Correo: Angela.quintero@prebel.com.co

Celular: 3234830720

### [VIN-02] 1. Certificados laborales › 1.2 Personal Impulso y mercado

Por favor relacionar los siguientes datos: nombre completo, número de cédula de ciudadanía, correo electrónico y celular

Encargada: Michell Román

Correo: michell.roman@prebel.com.co

Celular: 3147710112

### [VIN-03] 1. Certificados laborales › 1.3 Personal administrativo

El certificado laboral puede ser descargado desde la prebelnet en la opción de certificado laboral. En caso de no tener habilitada la opción en la prebelnet, comunicarse con la mesa de servicios. Si requieres un certificado laboral con funciones lo debes solicitar a Michell Román.

Encargada: Michell Román

Correo: michell.roman@prebel.com.co

Celular: 3147710112

### [VIN-04] 2. Requisitos retiro de cesantías › Compra de vivienda

- Carta dirigida a Gestión Humana, en la cual se debe especificar el motivo y cuales cesantías desea retirar (las causadas en el fondo y/o las causadas en el presente año), la carta debe estar firmada y con numero de contacto.

- Adjuntar la promesa de compraventa firmada en notaria

- Certificado del inmueble o matricula inmobiliaria **(No debe superar el mes de vigencia).**

- Enviar la documentación escaneada al correo lucia.mejias@prebel.com.co y también física a nómina.

Dudas o inquietudes: WhatsApp 3104589490.

### [VIN-05] 2. Requisitos retiro de cesantías › Reforma de vivienda

- Carta dirigida a Gestión Humana, en la cual se debe especificar el motivo y cuales cesantías desea retirar (las causadas en el fondo y/o las causadas en el presente año), la carta debe estar firmada y con numero de contacto.
- Adjuntar el impuesto predial vigente a nombre del empleado, si está a nombre del conyugue adicionar fotocopia del registro civil de matrimonio, y si se encuentra en unión libre, la declaración de extra juicio actualizada.
- Adjuntar las cotizaciones a nombre del empleado
- Foto del lugar a remodelar
- En caso de requerir un oficial de obra, debe presentar cotización y debe estar inscrito en la cámara de comercio (RUT), posteriormente la cuenta de cobro que expida debe tener firma autenticada en notaria.
- Enviar la documentación escaneada al correo lucia.mejias@prebel.com.co y entregarla física en nómina.

Dudas o inquietudes: WhatsApp 3104589490

### [VIN-06] 2. Requisitos retiro de cesantías › Pago de impuesto predial

- Carta dirigida a Gestión Humana, en la cual se debe especificar el motivo y cuales cesantías desea retirar (las causadas en el fondo y/o las causadas en el presente año), la carta debe estar firmada y con numero de contacto.
- Adjuntar la factura del impuesto predial, debe estar a nombre del empleado, en caso de estar a nombre del conyugue adjuntar la fotocopia del registro civil de matrimonio o si están en unión libre la declaración extra juicio actualizada.
- Enviar la documentación escaneada al correo lucia.mejias@prebel.com.co y entregarla física en nómina.

Dudas o inquietudes: WhatsApp 3104589490

### [VIN-07] 2. Requisitos retiro de cesantías › Pago de crédito hipotecario

- Carta dirigida a Gestión Humana, en la cual se debe especificar el motivo y cuales cesantías desea retirar (las causadas en el fondo y/o las causadas en el presente año), la carta debe estar firmada y con numero de contacto.
- Adjuntar el certificado donde se muestre la deuda que tenga con dicha entidad, debe estar a nombre del empleado, en caso de estar a nombre del conyugue adjuntar la fotocopia del registro civil de matrimonio o si están en unión libre la declaración extra juicio actualizada.
- Enviar la documentación escaneada al correo lucia.mejias@prebel.com.co y entregarla física en nómina.

Dudas o inquietudes: WhatsApp 3104589490

### [VIN-08] 2. Requisitos retiro de cesantías › Gastos notariales (solo escrituras)

- Carta dirigida a Gestión Humana, en la cual se debe especificar el motivo y cuales cesantías desea retirar (las causadas en el fondo y/o las causadas en el presente año), la carta debe estar firmada y con numero de contacto.
- Adjuntar la liquidación notarial de los gastos
- Enviar la documentación escaneada al correo lucia.mejias@prebel.com.co y entregarla física en nómina.

Dudas o inquietudes: WhatsApp 3104589490

### [VIN-09] 2. Requisitos retiro de cesantías › Estudio (directamente con el fondo de cesantías)

En este caso Prebel no es intermediario para el retiro.

El empleado debe ir personalmente al fondo, el fondo de cesantías girará directamente a la entidad educativa y descontará el anticipo del saldo del trabajador, debe llevar:
- Fotocopia legible del documento de identificación
- Recibo de matrícula o certificación de la institución educativa
- Si el pago de matrícula es para el conyugue, adjuntar la fotocopia del registro civil de matrimonio o si están en unión libre la declaración extra juicio actualizada
- Si el pago de matrícula es para hijos adjuntar la fotocopia del registro civil de nacimiento.

### [VIN-10] 3. Inclusiones EPS

Estos son los beneficiarios que puedes tener en la eps:

*   • El cónyuge o compañero permanente del cotizante.
*   • Tus hijos o los hijos de tu cónyuge o compañero, menores de 18 años o entre los 18 y 25 años si son estudiantes y dependen económicamente de ti como cotizante.
*   • Los hijos con incapacidad permanente.
*   • Si no tienes cónyuge o compañero, ni hijos a cargo, podrás afiliar a tus padres como beneficiarios básicos si dependen económicamente de ti.

Si estas en EPS sura, este es el paso a paso que debes seguir para realizar la inclusión:

1.  Ingresar a la página de EPS SURA - https://www.epssura.com/
2.  Dar clic en el botón iniciar sesión y escoger la opción Servicios en Línea Afiliados
3.  En esta opcion, debe crear una cuenta. Si ya la tiene creada debe iniciar sesion con el usuario y la clave que tiene asignados.
4.  cuando haya iniciado sesión, desplegar el menú “Afiliaciones y Retiros” y escoger la opción “ Formulario para ingreso de beneficiario”
5.  Dar clic en Si en todas las preguntas de la encuesta
6.  Ingresar el correo electrónico del cotizante. Dar clic en la opción “Agregar beneficiarios” y diligenciar el formulario con toda la información del beneficiario.
7.  Guardar el formulario y continuar con la firma virtual
8.  Cuando finaliza la firma virtual, al correo que registró inicialmente le va a llegar el formulario diligenciado y las indicaciones de los documentos que debe adjuntar, porque debe darle respuesta a ese correo.
9.  A su correo electrónico le llegará la confirmación exitosa de la inclusión

Si estas afiliado en otra EPS y deseas realizar la inclusión de un beneficiario, comunícate con la persona encargada Según el público al que pertenezcas:

### [VIN-11] 3. Inclusiones EPS › 3.1 Personal operativo

**Encargada:** Angela Quintero
**Correo:** Angela.quintero@prebel.com.co

Celular: 3234830720

### [VIN-12] 3. Inclusiones EPS › 3.2 Personal Impulso y mercado

Encargada: Michell Román
Correo: michell.roman@prebel.com.co
Celular: 3147710112

### [VIN-13] 3. Inclusiones EPS › 3.3 Personal administrativo

Encargada: Michell Román
Correo: michell.roman@prebel.com.co
Celular: 3147710112

### [VIN-14] 4. Inclusión caja de compensación familiar

Estos son los beneficiarios que puedes tener en la caja de compensación familiar.

• Hijos menores de 18 años
• Hijos estudiantes entre 18 y hasta los 23 años de edad.
• Hijos mayores de 18 años en situación de discapacidad
• Hijastros
• Esposo
• Compañero permanente
• Madre/padre: También puedes afiliar a tus padres mientras dependan de ti económicamente y no tengan fuentes de ingreso fijas como pensión o renta.
• Hermanos huérfanos de padres, mientras dependan de ti económicamente.
• Padres, hijos, hijastros y hermanos con discapacidad, mientras dependan de ti económicamente.

Documentos que debes presentar si quieres hacer la inclusión en la caja de compensación Comfama si trabajas en el departamento de Antioquia.

Para afiliar a tu grupo familiar como trabajador dependiente de una empresa debes tener a la mano los siguientes documentos para adjuntar en tu solicitud digital.

### [VIN-15] 4. Inclusión caja de compensación familiar › Cónyuge o compañero (a) permanente

• Documento de identidad.
• Formato de declaración juramentada (si estas en unión libre(o registro civil de matrimonio (si estas casado)
• Link para descargar el formato de declaración juramentada:
https://serviciosenlinea.comfama.com/Contenidos/Servicios/MarketingCloud/2024/MercadeoEmpresas/PDF/Declaracion-juramentada-Comfama.pdf?_gl=1\*k8y9u8\*\_gcl\_au\*MTk2MjA2MzU1LjE3Mzu4NTI3MDA.\*\_ga\*MTcwMDY2MTY2LjE3MTcxMDAyNTQ.\*\_ga_1V3L85HTHH\*MTczOTgxODIwNS4yMC4wLjE3Mzk4MTgyMTAuNTUuMC4w

### [VIN-16] 4. Inclusión caja de compensación familiar › Hijo(s)

• Registro civil de nacimiento.
• Tarjeta de identidad (a partir de los 7 años, igual se debe adjuntar el registro civil de nacimiento)
• Cedula de ciudadanía (a partir de los 18 años)
• Certificado de discapacidad de la entidad competente que certifique persona con discapacidad. (En caso de que aplique).
• Certificado de escolaridad para personas a cargo entre los 12 y los 18 años, que se encuentren realizando estudios en establecimientos educativos previamente aprobados; y personas a cargo hasta los 23 años de edad que estén cursando programas de Educación para el Trabajo y el Desarrollo humano, esto en cumplimiento con lo establecido en la Ley 789 de 2002 y el Decreto 4904 de 2009.

### [VIN-17] 4. Inclusión caja de compensación familiar › Hijastro(s)

• Registro civil de nacimiento.
• Tarjeta de identidad (a partir de los 7 años, igual se debe adjuntar el registro civil de nacimiento)
• Cedula de ciudadanía (a partir de los 18 años)
• Formato de declaración juramentada. Link para descargar el formato de declaración juramentada:
https://serviciosenlinea.comfama.com/Contenidos/Servicios/MarketingCloud/2024/MercadeoEmpresas/PDF/Declaracion-juramentada-Comfama.pdf?_gl=1*k8y9u8*_gcl_au*MTk2MjA2MzU1LjE3MzU4NTI3MDA.*_ga*MTcwMDY2MTY2LjE3MTcxMDAyNTQ.*_ga_1V3L85HTHH*MTczOTgxODIwNS4yMC4wLjE3Mzk4MTgyMTAuNTUuMC4w
• Certificado de discapacidad de la entidad competente que certifique persona con discapacidad. (En caso de que aplique).
• Certificado de escolaridad para personas a cargo entre los 12 y los 18 años, que se encuentren realizando estudios en establecimientos educativos previamente aprobados; y personas a cargo hasta los 23 años de edad que estén cursando programas de Educación para el Trabajo y el Desarrollo humano, esto en cumplimiento con lo establecido en la Ley 789 de 2002 y el Decreto 4904 de 2009.

### [VIN-18] 4. Inclusión caja de compensación familiar › Padres

• Documento de identidad.
• Certificado de afiliación a EPS.

• Registro civil de nacimiento del trabajador.

• Formato de declaración juramentada. Link para descargar el formato de declaración juramentada:
https://serviciosenlinea.comfama.com/Contenidos/Servicios/MarketingCloud/2024/MercadeoEmpresas/PDF/Declaracion-juramentada-Comfama.pdf?_gl=1*k8y9u8*_gcl_au*MTk2MjA2MzU1LjE3MzU4NTI3MDA.*_ga*MTcwMDY2MTY2LjE3MTcxMDAyNTQ.*_ga_1V3L85HTHH*MTczOTgxODIwNS4yMC4wLjE3Mzk4MTgyMTAuNTUuMC4w

• Certificado de discapacidad de la entidad competente que certifique persona con discapacidad. (En caso de que aplique).

### [VIN-19] 4. Inclusión caja de compensación familiar › Hermano(s) huérfanos

• Registro civil de nacimiento.

• Tarjeta de identidad (a partir de los 7 años, igual se debe adjuntar el registro civil de nacimiento)

• Cedula de ciudadanía (a partir de los 18 años)

• Registro civil de nacimiento del trabajador.

• Registro de defunción de padre y madre.

• Formato de declaración juramentada. Link para descargar el formato de declaración juramentada:
https://serviciosenlinea.comfama.com/Contenidos/Servicios/MarketingCloud/2024/MercadeoEmpresas/PDF/Declaracion-juramentada-Comfama.pdf?_gl=1*k8y9u8*_gcl_au*MTk2MjA2MzU1LjE3MzU4NTI3MDA.*_ga*MTcwMDY2MTY2LjE3MTcxMDAyNTQ.*_ga_1V3L85HTHH*MTczOTgxODIwNS4yMC4wLjE3Mzk4MTgyMTAuNTUuMC4w

• Certificado de discapacidad de la entidad competente que certifique persona con discapacidad. (En caso de que aplique).

• Certificado de escolaridad para personas a cargo entre los 12 y los 18 años, que se encuentren realizando estudios en establecimientos educativos previamente aprobados; y personas a cargo hasta los 23 años de edad que estén cursando programas de Educación para el Trabajo y el Desarrollo humano, esto en cumplimiento con lo establecido en la Ley 789 de 2002 y el Decreto 4904 de 2009.

Si deseas realizar la inclusión de un beneficiario, comunícate con la persona encargada Según el público al que pertenezcas:

### [VIN-20] 4. Inclusión caja de compensación familiar › Personal operativo

Encargada: Angela Quintero
Correo: Angela.quintero@prebel.com.co

Celular: 3234830720

### [VIN-21] 4. Inclusión caja de compensación familiar › Personal Impulso y mercado

Encargada: Michell Román
Correo: michell.roman@prebel.com.co
Celular: 3147710112

### [VIN-22] 4. Inclusión caja de compensación familiar › Personal administrativo

Encargada: Michell Román
Correo: michell.roman@prebel.com.co
Celular: 3147710112

Si te encuentras en otro departamento y deseas realizar la inclusión de un beneficiario, comunícate

Encargada: Michell Román
Correo: michell.roman@prebel.com.co
Celular: 3147710112

### [VIN-23] 5. Traslados EPS

Te comparto la información que debes tener en cuenta para realizar un traslado de EPS.

* Los traslados de EPS se deben realizar los 5 primeros dias hábiles de cada mes.
* Debe haber cotizado mínimo 1 año en la EPS donde está afiliado(a) actualmente.
* Debe tener en cuenta que usted o en caso de que tenga beneficiarios, no deben estar en algún tratamiento médico, pues de ser aceptados en la entidad que solicitas, deben comenzar desde cero.

Si deseas realizar el traslado, debes compartir por favor los siguientes datos.

* Nombre completo
* EPS actual
* Eps a trasladar
* Tipo de documento
* Numero de documento
* Fecha de expedición
* Fecha de nacimiento
* Correo electrónico
* Dirección residencia
* Barrio
* Ciudad
* Departamento
* Teléfono

Celular
RH

Si tienes beneficiarios:

Nombre completo
Tipo de documento
Numero de documento
Fecha de nacimiento
RH

Si deseas hacer un traslado de eps, debes enviar la información a la persona encargada, según el público al que pertenezcas:

### [VIN-24] 5. Traslados EPS › 5.1 Personal operativo

Encargada: Angela Quintero
Correo: Angela.quintero@prebel.com.co
Celular: 3234830720

### [VIN-25] 5. Traslados EPS › 5.2 Personal Impulso y mercado

Encargada: Michell Román
Correo: michell.roman@prebel.com.co
Celular: 3147710112

### [VIN-26] 5. Traslados EPS › 5.3 Personal administrativo

Encargada: Michell Román
Correo: michell.roman@prebel.com.co
Celular: 3147710112

### [VIN-27] 6. Proceso traslado de fondo de pensiones privado a Colpensiones

Para proceder con el traslado a Colpensiones, debe tener en cuenta lo siguiente:

1. Los traslados se realizan los 5 primeros días hábiles del mes.

2. Debe llevar mínimo 5 años de afiliación en el fondo de pensiones actual.

3. Recibir la doble asesoría, tanto del régimen público como del privado, para que le expliquen cuál podrá ser el futuro de su pensión si decide jubilarse con ellos, por favor tener en cuenta que recibir la asesoría de ambos regímenes es un requisito para poder tramitar la solicitud de traslado.

### [VIN-28] 6. Proceso traslado de fondo de pensiones privado a Colpensiones › Opciones para recibir la asesoría del fondo de pensiones privado (Depende del fondo donde se encuentre afiliado)

- Acercarse a una sucursal física
- Comunicarse a la línea telefónica asignada por el fondo.

### [VIN-29] 6. Proceso traslado de fondo de pensiones privado a Colpensiones › Opciones para recibir la asesoría de Colpensiones

- Acercarse a una sucursal física
- Comunicarse a la línea telefónica:
  Bogotá (57+601) 4890909
  Medellín (57+604) 2836090
  Línea gratuita nacional: 018000410909
- Descargar la aplicación de Colpensiones
- Solicitar la cita a través del siguiente link

https://sede.colpensiones.gov.co/loader.php?lServicio=Se&lTipo=Process&lFuncion=start&id=59&gov=1

4. Si después de recibir la doble asesoría, su decisión es trasladarse a Colpensiones, debe dirigirse a la pagina web https://www.colpensiones.gov.co/ y hacer clic en el banner principal, una vez esté allí debe registrarse, obtener usuario, contraseña y contestar las preguntas de validación. Posterior a ello, deberá ingresar nuevamente al aplicativo, dar clic en la opción de traslado y realizar el paso a paso. Si la persona cumple con los requisitos, la respuesta del traslado la recibirá entre 5 a 10 minutos después.

5. Cuando haya hecho el traslado, por favor enviarnos el soporte para archivarlo en la hoja de vida y hacer los aportes correctos de seguridad social.

Enviar el soporte a los correos:

### [VIN-30] 6. Proceso traslado de fondo de pensiones privado a Colpensiones › Si perteneces a la nómina administrativa

- Michell.roman@prebel.com.co
- Shirley.silgado@prebel.com.co

### [VIN-31] 6. Proceso traslado de fondo de pensiones privado a Colpensiones › Si perteneces a la nómina operativa

- Yasmin.yepes@prebel.com.co
- Angela.quintero@prebel.com.co

### [VIN-32] 6. Proceso traslado de fondo de pensiones privado a Colpensiones › Si perteneces a la nómina de impulso y mercadeo

- Lucia.mejias@prebel.com.co

### [VIN-33] 7. Dias de vacaciones › Administrativa

Si perteneces a la nómina administrativa, puedes visualizar tus días de vacaciones ingresando a la Prebelnet, das clic en solicitud de vacaciones y al lado de tu nombre aparecen los días disponibles.

### [VIN-34] 7. Dias de vacaciones › Operativa

Si perteneces a la nómina operativa, el área de nómina cada quincena reporta a los jefes, coordinadores y líderes el pasivo de vacaciones. La consulta de tus días de vacaciones la puedes hacer con ellos

### [VIN-35] 7. Dias de vacaciones › Impuso y mercado

Si perteneces a la nómina impulso y mercado, los días de vacaciones que tienes disponibles los puedes consultar con linda Salamanca, al correo linda.salamanca@prebel.com.co o al celular 3102150234

### [VIN-36] 8. Incapacidades

Todos los colaboradores de Prebel cuando tengan una incapacidad médica deberán hacerla llegar a la compañía, a través de los medios dispuestos en máximo 5 días hábiles después de la ocurrencia del evento que originó la incapacidad.

• Prebel solo aceptará las incapacidades que sean expedidas por la ARL, EPS o IPS autorizadas, por medio de transcripción.
• Si la incapacidad no es entregada dentro de los treinta (30) días siguientes, contados desde la fecha de inicio de la incapacidad, la empresa se reserva el derecho de no reconocer ni pagar la incapacidad médica correspondiente, y se considerará la ausencia como injustificada.
• El trabajador podrá solicitar una prórroga o justificación para el incumplimiento de este plazo, la cual será evaluada a discreción de la Gerencia de Gestión Humana, dependiendo de las circunstancias particulares del caso.

El envío de la incapacidad de debe hacer así, según el público al que pertenezcas:
- "Si perteneces a la nómina administrativa, lo realizas ingresando a la Prebelnet, en la pantalla de inicio das clic en el botón Reportes de incapacidades."
- "Si perteneces a la nómina operativa, debes realizar el envío de la incapacidad al correo incapacidades@prebel.com.co."
- "Si perteneces a la nómina impulso y mercado, debes realizar el envío de la incapacidad al correo lucia.mejias@prebel.com.co o al WhatsApp 310 4589490."

### [VIN-37] 9. Soporte de Pago Seguridad social

A partir del mes de noviembre de 2024, al correo electrónico registrado (corporativo o personal) llega el comprobante de pago de seguridad social, este reporte lo recibirás de manera mensual una vez se realice el pago en las fechas establecidas. El remitente del correo es seguridadsocial@enlace.com.co quien es el operador por medio del cual realizamos nuestros aportes de seguridad social.

Si quieres descargar el certificado de pago de seguridad social, ingresa al siguiente link, debes ingresar tu numero de cedula y en periodo de cotización, eliges el mes del cual requieres el soporte:

https://www.suaporte.com.co/Web/faces/pages/comprobantes/consultadirecta/consultaDirectaLogin.xhtml?_gl=1*nciiz9*_gcl_au*NzEzMzExMDIxLjE2OTExNzl2MjU

### [VIN-38] 11. Actualización de datos

Actualiza tus datos a través del siguiente link, el formulario aplica para todos los empleados de la compañía, con la finalidad de conservar sus datos actualizados. El formulario tiene un máximo de 51 preguntas y el tiempo de respuesta es máximo de 10 minutos. Eres parte importante para nuestra compañía, queremos saber de ti y continuar embelleciendo tu vida

Link: https://forms.office.com/pages/responsepage.aspx?id=p9cTIgLizUuidV5_Y-2AMjiCkwIQ9xpJqeG_WtnqK5VUQTNRTTdGQ01VRVk0WUVHRzFOUVFTSzE2Ui4u&origin=lprLink

## Créditos Prebel (Creditos_Prebel_20260310.md, 10/03/2026)

### [CRE-01] Crédito para educación y/o compra de computadores para estudio › ¿Qué es el crédito para educación y/o compra de computadores para estudio?

Es un crédito que apoya la formación de los empleados(as) de Prebel S.A., en áreas técnicas, tecnológicas o profesionales, relacionadas con las competencias requeridas al interior de la Compañía o la compra de un computador para adelantar dichos estudios; brindando apoyo económico a través de un fondo de crédito sin intereses por un plazo de 12 meses.

### [CRE-02] Crédito para educación y/o compra de computadores para estudio › ¿Quiénes son beneficiarios del crédito para educación y/o compra de computadores para estudio?

Serán beneficiarios de los préstamos del fondo para crédito de educación y compra de computadores para estudio formal, los empleados de la compañía cuyos ingresos mensuales no superen los 6 SMLMV, que deseen realizar estudios técnicos, tecnológicos o profesionales, relacionadas con las competencias requeridas al interior de la Compañía, o que requieren un computador para adelantar tales estudios.

### [CRE-03] Crédito para educación y/o compra de computadores para estudio › ¿A quién me puedo dirigir para presentarle mi solicitud de crédito para educación y/o compra de computadores para estudio?

Puedes contactarte con Stefanny Pulgarín Correa, Analista de Bienestar y RSE.

Teléfono: 3104057760

Correo: stefanny.pulgarin@prebel.com.co

### [CRE-04] Crédito para educación y/o compra de computadores para estudio › ¿Cuáles son los requisitos para solicitar el de crédito para educación y/o compra de computadores para estudio?

1. Presentar un formulario de crédito diligenciado y firmado, con visto bueno del jefe inmediato (este formulario será suministrado por Stefanny Pulgarín).
2. Presentar liquidación de la matrícula en caso de financiación en formación educativa.
3. Cotización o factura de compra en caso de compra de computador.

4. Contar con una capacidad de endeudamiento inferior al 42% del ingreso nominal, incluyendo cuota del préstamo.
5. Para el otorgamiento de los créditos se tendrá en cuenta elementos como evaluación de desempeño del colaborador y el concepto del jefe.
6. En el evento en que un empleado haya sido privilegiado anteriormente con un crédito de educación y requiera uno nuevo, para acceder será necesario que cumpla con los requisitos de este reglamento y que el monto de los créditos sumados no supere 2 SMLMV.
7. Prebel podrá solicitar documentos adicionales no enunciados en los numerales anteriores en caso de considerarlo necesario.

### [CRE-05] Crédito para educación y/o compra de computadores para estudio › ¿Cuáles son las condiciones del crédito para educación y/o compra de computadores para estudio?

1. La cuantía del préstamo será de acuerdo con la necesidad del empleado, siendo el monto máximo 2 SMLMV.
2. Las tasas de intereses serán causadas al 0%
3. El plazo del crédito será de hasta 12 meses.
4. En caso de que el beneficiario realice abonos extraordinarios del crédito no habrá lugar a la disminución del valor de la cuota.
5. Todo beneficiario del crédito firmará pagaré en blanco con carta de instrucciones a favor de Prebel y diligenciará una autorización de descuento periódico de su nómina de acuerdo con las fechas de pago de esta. El empleado podrá pignorar las primas y/o auxilios. Además, autorizará que, a partir del otorgamiento de este, el valor total de su liquidación definitiva de salarios, prestaciones o eventual indemnización o cualquier otro tipo de pago derivado de la vinculación laboral sea destinado al pago o abono a la deuda si por alguna circunstancia llegare a producirse su retiro de la compañía antes de la cancelación de esta.
6. El empleado deberá legalizar los soportes del crédito dentro de los 30 días siguientes a su desembolso (Pago de facturas). El incumplimiento a esta obligación se considerará como falta grave sometida a proceso

disciplinario. Adicionalmente, el empleado deberá retornar el dinero de manera inmediata.

### [CRE-06] Crédito para educación y/o compra de computadores para estudio › ¿Cuánto tarda el proceso de aprobación del crédito para educación y/o compra de computadores para estudio?

Una vez presentados todos los documentos, el proceso de aprobación puede tardar hasta dos semanas hábiles.

### [CRE-07] Crédito para educación y/o compra de computadores para estudio › ¿Cómo es el proceso de desembolso para el crédito de educación y/o compra de computadores para estudio?

El desembolso se realizará, una vez se apruebe la solicitud, a la cuenta bancaria del empleado registrado en la compañía.

### [CRE-08] Crédito para educación y/o compra de computadores para estudio › ¿El crédito para educación y/o compra de computadores para estudio aplica para mis familiares?

No, este crédito solo aplica para los colaboradores directos de la compañía.

***

### [CRE-09] Crédito de grave calamidad doméstica de mascotas › ¿Qué es el crédito de grave calamidad doméstica de mascotas?

Es un crédito que apoya a los empleados de Prebel S.A BIC en solucionar de manera oportuna las situaciones de calamidad (gastos inmediatos por cirugías, hospitalización, exámenes, medicamentos o gastos fúnebres) que puedan presentarse con sus animales de compañía (perros o gatos), brindando apoyo económico a través de un fondo de crédito sin intereses.

### [CRE-10] Crédito de grave calamidad doméstica de mascotas › ¿Quiénes son beneficiarios del crédito de grave calamidad doméstica de mascotas?

Personal vinculado directamente con Prebel, que presente situaciones de calamidad con sus animales de compañía. Este crédito es solo para colaboradores y no se extiende para sus familiares.

### [CRE-11] Crédito de grave calamidad doméstica de mascotas › ¿Cuáles son las destinaciones para el crédito de grave calamidad doméstica de mascotas?

• Cirugías.
• Hospitalización.
• Exámenes.
• Medicamentos.
• Gastos fúnebres.

### [CRE-12] Crédito de grave calamidad doméstica de mascotas › ¿A quién me puedo dirigir para presentarle mi solicitud de crédito de grave calamidad doméstica de mascotas?

Puedes contactarte con Stefanny Pulgarín Correa, Analista de Bienestar y RSE.

Teléfono: 3104057760

Correo: stefanny.pulgarin@prebel.com.co

### [CRE-13] Crédito de grave calamidad doméstica de mascotas › ¿Cuáles son los requisitos para solicitar el crédito de grave calamidad doméstica de mascotas?

1. Presentar un formulario de crédito diligenciado y firmado, con visto bueno del jefe inmediato.
2. Cotización o relación de gastos.
3. En el caso de hospitalización, citas o exámenes, estos deben ser cubiertos por entidades de veterinaria certificadas, de seguros u otras, mediante RUT o Cámara de Comercio.
4. Aportar un extra-juicio en el cual se indique la propiedad de la mascota y la situación de grave calamidad.
5. Contar con unas deducciones inferiores al 50% del ingreso nominal, incluyendo cuota del préstamo.
6. La mascota debe de estar registrada en la base de datos de la compañía.

7. Para el otorgamiento de los créditos se tendrá en cuenta elementos como evaluación de desempeño del colaborador y el concepto del jefe.

8. En el evento en que un empleado haya sido privilegiado anteriormente con un crédito de calamidad para mascotas y requiera uno nuevo, para acceder será necesario que cumpla con los requisitos de este reglamento y que el monto de los créditos sumados no supere 2 SMLMV.

9. Prebel S.A BIC podrá solicitar documentos adicionales no enunciados en los numerales anteriores.

### [CRE-14] Crédito de grave calamidad doméstica de mascotas › ¿Cuáles son las condiciones para solicitar el crédito de grave calamidad doméstica de mascotas?

1. La cuantía del préstamo será de acuerdo con la necesidad del empleado, siendo el monto máximo 2 SMLMV.

2. Las tasas de intereses serán causadas al 0%

3. El plazo del crédito será de hasta 12 meses.

4. En caso de que el beneficiario realice abonos extraordinarios del crédito no habrá lugar a disminución del valor de la cuota.

5. Todo beneficiario del crédito firmará pagaré en blanco con carta de instrucciones a favor de Prebel y diligenciará una autorización de descuento periódico de su nómina de acuerdo con las fechas de pago de esta. El empleado podrá pignorar las primas y/o auxilios. Además, autorizará que, a partir del otorgamiento de este, el valor total de su liquidación definitiva de salarios, prestaciones legales o extralegales o eventual indemnización o cualquier otro tipo de pago derivado de la vinculación laboral sea destinado al pago o abono a la deuda si por alguna circunstancia llegare a producirse su retiro de la Compañía antes de la cancelación de ésta.

6. El empleado deberá legalizar los soportes del crédito dentro de los 30 días siguientes a su desembolso. El incumplimiento a esta obligación se considerará como falta grave sometida a proceso disciplinario.

### [CRE-15] Crédito de grave calamidad doméstica de mascotas › ¿Cuánto tarda el proceso de aprobación del crédito de grave calamidad doméstica de mascotas?

Una vez presentados todos los documentos, el proceso de aprobación puede tardar hasta 1 semana hábil.

### [CRE-16] Crédito de grave calamidad doméstica de mascotas › ¿Cómo es el proceso de desembolso para el crédito de grave calamidad doméstica de mascotas?

El desembolso se realizará, una vez se apruebe la solicitud, a la cuenta bancaria del empleado registrado en la compañía.

***

### [CRE-17] Crédito para casos especiales de salud › ¿Qué es el crédito para casos especiales de salud?

Este crédito apoya a los empleados de Prebel S.A BIC y sus familiares en primer grado de consanguinidad, cónyuge o compañero permanente, para sufragar gastos de situaciones médicas complejas, incluidos exámenes de diagnóstico, medicamentos, equipos médicos, citas con especialistas, cirugías, compra de anteojos y lentes de contacto, entre otros. Brindando apoyo económico a través de un fondo de crédito, para casos especiales de salud, sin intereses.

### [CRE-18] Crédito para casos especiales de salud › ¿Quiénes son beneficiarios del crédito para casos especiales de salud?

1. Empleado y su grupo familiar en primer grado de consanguinidad, para estos efectos hará parte del grupo familiar del empleado:
2. cónyuge o compañero(a) permanente.
3. hijos del empleado y/o de su cónyuge o compañero(a) permanente, siempre y cuando dependan económicamente del empleado y se encuentren afiliados por este a su seguridad social.
4. padres del empleado.

### [CRE-19] Crédito para casos especiales de salud › ¿Cuáles son las destinaciones para el crédito de casos especiales de salud?

Se destinará para sufragar gastos médicos en situaciones médicas complejas, incluidos exámenes de diagnóstico, medicamentos, equipos médicos, citas

con especialistas, cirugías, compra de anteojos y lentes de contacto, entre otros. Para los cuales deberán soportar documentos como: cotizaciones, descripción del procedimiento y los demás documentos que la compañía solicite de acuerdo con cada caso.

### [CRE-20] Crédito para casos especiales de salud › ¿A quién me puedo dirigir para presentarle mi solicitud de crédito de casos especiales de salud?

Puedes contactarte con Stefanny Pulgarín Correa, Analista de Bienestar y RSE.

Teléfono: 3104057760

Correo: stefanny.pulgarin@prebel.com.co

### [CRE-21] Crédito para casos especiales de salud › ¿Cuáles son los requisitos para solicitar el crédito de casos especiales de salud?

1. Presentar formulario de crédito diligenciado y firmado, con visto bueno del jefe inmediato.
2. En caso de hijos deberá presentar registro civil de nacimiento.
3. En caso de hijos de la compañera o compañero permanente: registro civil de nacimiento, declaración extra-juicio.
4. En caso de hijos de la compañera o compañero permanente, el área de Nómina realizará la validación en el sistema de seguridad social la calidad de beneficiario del empleado.
5. Para los padres del empleado copia de cédula de ciudadanía y registro civil de nacimiento del empleado.
6. Copia de la fórmula, orden médica o autorización, debidamente acreditados por el profesional respectivo.
7. Cotización o relación de gastos.
8. Contar con capacidad de deducciones de hasta el 42% del ingreso nominal, incluyendo cuota del préstamo.
9. Para el otorgamiento de los créditos se tendrá en cuenta elementos como evaluación de desempeño del colaborador y el concepto del jefe.
10. En el evento en que un empleado haya sido privilegiado anteriormente con un crédito de salud y requiera uno nuevo, para

acceder será necesario que cumpla con los requisitos de este reglamento y que el monto de los créditos sumados no supere 2 SMLMV.
11. El crédito no será otorgado con fines estéticos.
12. Prebel podrá solicitar documentos adicionales no enunciados en los numerales anteriores.

### [CRE-22] Crédito para casos especiales de salud › ¿Cuáles son las condiciones para solicitar el crédito de casos especiales de salud?

1. La cuantía del préstamo será de acuerdo con la necesidad del empleado, siendo el monto máximo 2 SMLMV.
2. Las tasas de intereses serán causadas al 0%
3. El plazo del crédito será de hasta 12 meses.
4. En caso de que el beneficiario realice abonos extraordinarios del crédito no habrá lugar a disminución del valor de la cuota.
5. Todo beneficiario del crédito firmará pagaré en blanco con carta de instrucciones a favor de Prebel y diligenciará una autorización de descuento periódico de su nómina de acuerdo con las fechas de pago de esta. El empleado podrá pignorar las primas y/o auxilios. Además, autorizará que, a partir del otorgamiento de este, el valor total de su liquidación definitiva de salarios, prestaciones o eventual indemnización o cualquier otro tipo de pago derivado de la vinculación laboral sea destinado al pago o abono a la deuda, si por alguna circunstancia, llegare a producirse su retiro de la Compañía antes de la cancelación de esta.
6. El empleado deberá legalizar los soportes del crédito dentro de los 30 días siguientes a su desembolso. El incumplimiento a esta obligación se considerará como falta grave sometida a proceso disciplinario. Adicionalmente, el empleado deberá retornar el dinero de manera inmediata.

### [CRE-23] Crédito para casos especiales de salud › ¿Cuánto tarda el proceso de aprobación del crédito de casos especiales de salud?

Una vez presentados todos los documentos, el proceso de aprobación puede tardar hasta 2 semanas hábiles.

### [CRE-24] Crédito para casos especiales de salud › ¿Cómo es el proceso de desembolso para el crédito de casos especiales de salud?

El desembolso se realizará, una vez se apruebe la solicitud, a la cuenta bancaria del empleado registrado en la compañía.

***

### [CRE-25] Crédito para préstamo de vivienda, reformas de vivienda, legalización de vivienda y pago de impuesto predial › ¿Qué es el crédito para préstamo de vivienda, reformas de vivienda, legalización de vivienda y pago de impuesto predial?

Es un crédito que apoya a los empleados de Prebel S.A. BIC y sus familias en obtener una solución de vivienda que mejore su calidad de vida, brindando apoyo económico a través de un sistema de crédito con tasas de interés privilegiadas. Con el propósito de mejorar la calidad de vida de los empleados, a través de la adquisición de la primera vivienda.

### [CRE-26] Crédito para préstamo de vivienda, reformas de vivienda, legalización de vivienda y pago de impuesto predial › ¿Quiénes son beneficiarios del crédito para préstamo de vivienda, reformas de vivienda, legalización de vivienda y pago de impuesto predial?

serán beneficiarios de los préstamos del fondo de crédito para préstamo de vivienda, reformas de vivienda, legalización de vivienda y pago de impuesto predial, quienes cumplan la totalidad de los siguientes requisitos:

1. Personal vinculado directamente con Prebel S.A BIC cuyos ingresos mensuales no superen los 6 SMLMV, salvo que se trate de créditos de calamidad habitacional, caso en el cual no habrá límite salarial.
2. Personal con antigüedad superior a 6 meses, salvo que se trate de créditos de calamidad habitacional, caso en el cual no se requerirá antigüedad.
3. El empleado debe habitar la vivienda (en caso de compra de vivienda).

### [CRE-27] Crédito para préstamo de vivienda, reformas de vivienda, legalización de vivienda y pago de impuesto predial › ¿Cuál es la destinación del préstamo del crédito para préstamo de vivienda, reformas de vivienda, legalización de vivienda y pago de impuesto predial?

1. **Adquisición de vivienda o lote:** compra de vivienda nueva, usada o lote, dirigido a colaboradores que no posean casa propia, ni su cónyuge o compañero permanente, ni ser propietario de ningún tipo de inmueble, salvo que tenga derecho en un solo inmueble diferente hasta en un 50%.
2. **Reformas de vivienda:** rubro orientado a consolidar o renovar las viviendas, mediante actividades de ampliación, reparación, reforzamiento estructural o rehabilitación que propicien una vivienda digna, siempre y cuando la vivienda sea de su propiedad plena o en comunidad con su cónyuge o compañero(a) permanente.
3. **Calamidades habitacionales:** consiste en reparaciones urgentes que requieran por parte del empleado una respuesta inmediata, ocasionadas por casos fortuitos o de fuerza mayor que afecten la vivienda de habitación del empleado (inundaciones, terremotos, avalanchas, deslizamientos y destrucción parcial o total de la vivienda, entre otros, así como daños que comprometan la estructura de la vivienda como desplazamiento de tejas, humedades, fallas en la estructura) siempre y cuando la vivienda sea de su propiedad plena o de su núcleo familiar (cónyuge o compañero(a) permanente, hasta segundo grado de consanguinidad y primero de afinidad).
4. **Legalización de inmuebles (compra, liberación de gravamen hipotecario, cancelación de leasing habitacional, adjudicación por liquidación de sociedad conyugal):** consiste en acreditar ante el Registro Público de la Propiedad, mediante escritura pública, que el bien quedara adscrito al empleado o libre de gravamen (escritura).
5. **Pago de impuesto predial:** rubro orientado al pago de impuesto predial de la vivienda del colaborador, su cónyuge o compañero permanente; para este último se solicitará registro civil de matrimonio o extra-juicio. Siempre y cuando no supere 3 años de vencido.

### [CRE-28] Crédito para préstamo de vivienda, reformas de vivienda, legalización de vivienda y pago de impuesto predial › ¿Cuáles son los requisitos generales del crédito para préstamo de vivienda, reformas de vivienda, legalización de vivienda y pago de impuesto predial?

1. Formulario de crédito diligenciado y firmado, con visto bueno del jefe inmediato.

2. El empleado beneficiario de un crédito deberá habitar la vivienda objeto de dicho crédito.
3. Todas las solicitudes de crédito serán estudiadas por el Comité de Crédito del Fondo de crédito para vivienda, acompañado de la documentación exigida para tal fin.
4. Para los préstamos destinados a la adquisición de vivienda, mejora de vivienda, calamidades habitacionales, legalización del inmueble, pago de impuesto predial, el inmueble debe ser habitable y con sus servicios públicos instalados.
5. Todo beneficiario de crédito de vivienda diligenciará una autorización de descuento periódico de su nómina de acuerdo con las fechas de pago de esta, con los compromisos adicionales conforme las garantías exigidas para cada tipo de crédito. Además, autorizará que, a partir del otorgamiento de este, el valor total de su liquidación definitiva de salarios, prestaciones legales y extralegales o eventual indemnización sea destinado al pago o abono a la deuda si por alguna circunstancia llegare a producirse su retiro de la Compañía antes de la cancelación de esta. El desembolso de un crédito que requiera constitución de hipoteca se realizará una vez haya sido registrada la escritura pública de constitución de hipoteca de primer grado a favor de Prebel S.A BIC en la Oficina de Registro de Instrumentos Públicos respectiva y hayan sido suscritos los documentos requeridos.
6. Los créditos que no requieran constitución de hipoteca serán desembolsados una vez se hayan revisado y aprobado los documentos solicitados.
7. La capacidad de deducción por nómina del colaborador, los requisitos técnicos y legales serán estudiados al momento de la preaprobación y al momento del desembolso. Una calificación negativa en cualquiera de estos momentos dará lugar a que el crédito sea negado.
8. En todos los tipos de créditos, el Comité podrá solicitar documentos adicionales no enunciados en los numerales anteriores.

### [CRE-29] Crédito para préstamo de vivienda, reformas de vivienda, legalización de vivienda y pago de impuesto predial › ¿Cuáles son las condiciones generales del crédito para préstamo de vivienda, reformas de vivienda, legalización de vivienda y pago de impuesto predial?

• El plazo del crédito será el determinado en cada caso según las condiciones particulares del mismo, siempre y cuando esta fecha no sea superior al tiempo que le faltare al empleado para su edad de pensión, caso en el cual, se ajustará el plazo del préstamo al tiempo que le faltare para pensionarse.

• Las tasas de interés serán las determinadas en cada caso según las condiciones particulares del tipo de crédito. Las tasas serán revisadas cada año para los nuevos créditos. La cuota de amortización quincenal incluirá el aporte de capital a la deuda del trabajador, más los intereses respectivos, desde el mismo momento que sea desembolsado el préstamo.

• En caso de que el beneficiario realice abonos extraordinarios del crédito, estos se utilizarán en primer lugar para abonar a capital, disminuyéndose el plazo del crédito.

• La Compañía prestará acompañamiento e interventoría respecto del desembolso de los créditos. En caso de que el dinero sea utilizado para fines distintos a los solicitados, habrá lugar a un proceso disciplinario por incumplimiento del acuerdo contra el empleado. Adicionalmente, el empleado deberá reembolsar de manera inmediata a Prebel S.A BIC el saldo pendiente de pago, acelerándose de esta manera el plazo.

• Los préstamos serán garantizados con hipoteca de primer grado sobre el inmueble a favor de Prebel S.A BIC. En todo caso, el crédito otorgado por la entidad financiera y por Prebel S.A. BIC, no podrán sumar más del setenta por ciento (70%) del avalúo de la vivienda objeto del préstamo. En el caso del crédito con destinación para cancelación de hipoteca, se permitirá temporalmente la constitución de hipoteca en segundo grado. Sin embargo, el empleado deberá presentar al fondo de crédito, dentro de los dos meses siguientes contados a partir del desembolso del crédito, el certificado de tradición del inmueble donde conste la cancelación de la hipoteca de primer grado. De lo contrario habrá lugar a los procesos disciplinarios correspondientes.

• No se otorgarán préstamos sobre inmuebles que se encuentren embargados o gravados por medidas que afecten o impidan que Prebel S.A BIC pueda hacer efectiva la garantía, como lo son las hipotecas,

afectaciones a patrimonio de familia, inembargable o a vivienda familiar. En estos casos deberá cancelarse el embargo o gravamen existente para que sea posible registrar la hipoteca de Prebel S.A BIC y realizar el respectivo desembolso.

• Dependiendo del tipo de crédito se solicitará la pignoración de cesantías a favor de Prebel S.A BIC consolidadas al 31 de diciembre de cada año, así como pignoración de las primas en un porcentaje mayor o igual al cincuenta por ciento (50%) de estas.

• Dependiendo del tipo de crédito se solicitará la constitución de pólizas de seguros: (I) De incendio y terremoto: por un valor equivalente al de reconstrucción del inmueble, siempre y cuando garantice el valor de la deuda. (II) De vida: por un valor mínimo equivalente a monto del crédito. El empleado autorizará a Prebel S.A BIC a descontar por nómina la cuota correspondiente al valor de los seguros.

• El empleado favorecido con un crédito de vivienda dispondrá de un plazo máximo para la utilización del préstamo de doce (12) meses contados a partir de su aprobación. Vencido este término sin que el empleado hubiere hecho uso de dicho préstamo, este le será cancelado. Para compra sobre planos, el plazo anterior será ampliado de acuerdo con el cronograma de entrega del inmueble por parte de la constructora. En el evento en que el empleado no pueda hacer uso del préstamo en este término por causas ajenas a su voluntad, el Comité de Crédito del Fondo de crédito para vivienda decidirá sobre la ampliación o cancelación del crédito.

• Los gastos ocasionados con motivo de la legalización del crédito, tales como constitución de hipotecas, cancelación de gravámenes, gastos notariales, rentas y de registro, etc., serán cubiertos en su totalidad por el empleado.

### [CRE-30] Crédito para préstamo de vivienda, reformas de vivienda, legalización de vivienda y pago de impuesto predial › ¿Cuáles son los requisitos para la adquisición de vivienda o lote?

1. Cuantía máxima: 50 SMLMV al momento de la preaprobación por el Comité de Crédito del Fondo de crédito para vivienda.
2. Plazo: 15 años.

3. Intereses: 6% efectivo anual.
4. Garantía: Hipoteca en primer grado a favor de Prebel S.A. BIC. En todo caso, el crédito otorgado por la entidad financiera y por Prebel S.A., no podrán sumar más del setenta por ciento (70%) del avalúo de la vivienda objeto del préstamo.
5. Suscripción de pagaré y pignoración de primas y cesantías.
6. Contar con los recursos para la compra de la vivienda, los cuales se deben demostrar en cuenta de ahorro programado, cesantías, fondo de empleados y/o subsidio de Caja de Compensación. Estos no podrán ser inferiores a 5 SMLMV.
7. Cumplir con las especificaciones técnicas y legales de la vivienda (peritaje).
8. Asumir el valor del avalúo del inmueble, el cual será realizado por el perito que designe la Compañía.
9. Contar con un endeudamiento inferior al 42% del ingreso nominal, incluyendo la cuota de vivienda.
10. Tomar seguro de vida y de vivienda a favor de Prebel S.A BIC, cuyo pago estará incluido en la cuota mensual. En caso de que el empleado o el inmueble sea rechazado por la aseguradora, la solicitud de crédito no será aprobado.
11. Escritura de adquisición anterior del inmueble.
12. Certificado de tradición del inmueble con menos de 15 días de expedición.
13. Promesa de compraventa firmada con reconocimiento de firma y contenido ante notario. La promesa debe contener: identificación de las partes (comprador y vendedor), identificación del inmueble (dirección y matrícula), precio, forma de pago, fecha de la firma de la escritura.

### [CRE-31] Crédito para préstamo de vivienda, reformas de vivienda, legalización de vivienda y pago de impuesto predial › ¿Cuáles son los requisitos para reforma de vivienda?

1. Cuantía máxima: 5 SMLMV al momento de la preaprobación por el Comité de Crédito del Fondo de crédito para vivienda.
2. Plazo: 3 años.
3. Intereses: 6% efectivo anual.

4. Garantía: Suscripción de pagaré y pignoración de primas.
5. Cumplir con las especificaciones técnicas y legales de la vivienda.
6. Contar con un endeudamiento inferior al 42% del ingreso nominal, incluyendo la cuota del crédito.
7. Demostrar que el inmueble sobre el cual se va a realizar la construcción pertenece al empleado y/o a su cónyuge o compañero (a) permanente.
8. Escritura de adquisición del inmueble.
9. Certificado de tradición del inmueble con menos de 15 días de expedición.
10. Presupuesto de los materiales a emplear donde se especifique detalladamente los materiales, valores y forma de pago (cotización legalmente aprobada).
11. Presupuesto de las obras a realizar donde se especifique detalladamente tipo de obra, valores y forma de pago. (RUT y existencia del contratista y/o proveedor no menor a un año).
12. Utilizar los materiales con una entidad legalmente constituida y reconocida en el mercado no menor a cinco años de existencia. El incumplimiento de este requisito dará lugar al procedimiento disciplinario correspondiente contra el trabajador. La compañía prestará acompañamiento e interventoría respecto de este requisito, al momento de efectuar los desembolsos. En caso de que el dinero sea utilizado para fines distintos, habrá lugar a un proceso disciplinario por incumplimiento del acuerdo contra el empleado. Adicionalmente, reembolsará de manera inmediata a Prebel S.A BIC el saldo pendiente de pago, acelerándose de esta manera el plazo.
13. Este crédito no aplica sobre obras ya realizadas y/o materiales o insumos ya comprados.

### [CRE-32] Crédito para préstamo de vivienda, reformas de vivienda, legalización de vivienda y pago de impuesto predial › ¿Cuáles son los requisitos para calamidades habitacionales?

1. Cuantía máxima: 5 SMMLV al momento de la preaprobación por el Comité de Crédito del Fondo de crédito para vivienda. El Comité podrá

ampliar la cuantía máxima conforme las condiciones particulares de la situación.
2. Plazo: 3 años. El Comité podrá ampliar el plazo conforme las condiciones particulares de la situación.
3. Intereses: 0%
4. Garantía: Suscripción de pagaré y pignoración de primas.
5. Cumplir con las especificaciones técnicas y legales de la vivienda.
6. Contar con un endeudamiento inferior al 50% del ingreso nominal, incluyendo la cuota del crédito.
7. Utilizar los materiales con una entidad legalmente constituida y reconocida en el mercado no menor a cinco años de existencia. El incumplimiento de este requisito dará lugar al procedimiento disciplinario correspondiente contra el trabajador.
8. Demostrar que el inmueble sobre el cual se van a realizar las mejoras o reparaciones pertenece al empleado o su núcleo familiar (su cónyuge o compañero permanente, hasta segundo grado de consanguinidad y primero de afinidad) donde habite el empleado.
9. Certificado de tradición del inmueble con menos de 15 días de expedición.
10. Licencia de construcción vigente y expedida por la entidad competente, en caso de que las mejoras a realizar así lo requieran.
11. Presupuesto de las obras a realizar donde se especifique detalladamente tipo de obra, valores y forma de pago.
12. Factura de compra donde se especifique detalladamente tipo de obra, valores y forma de pago.

### [CRE-33] Crédito para préstamo de vivienda, reformas de vivienda, legalización de vivienda y pago de impuesto predial › ¿Cuáles son los requisitos para legalización del inmueble?

1. Cuantía máxima: 7 SMLMV al momento de la preaprobación por el Comité de Crédito del Fondo de crédito para vivienda
2. Plazo: 3 años
3. Intereses: 6% efectivo anual
4. Garantía: Suscripción de pagaré y pignoración de primas.
5. Contar con un endeudamiento inferior al 42% del ingreso nominal, incluyendo la cuota del crédito.

6. Escritura de adquisición del inmueble.
7. Certificado de tradición del inmueble con menos de 15 días de expedición.
8. Demás documentos requeridos por el área Legal de Prebel S.A BIC según el caso específico.

### [CRE-34] Crédito para préstamo de vivienda, reformas de vivienda, legalización de vivienda y pago de impuesto predial › ¿Cuáles son los requisitos para la liberación de gravámenes hipotecarios?

1. Comprobar la existencia de la deuda a favor de una entidad financiera acreditada por la Superintendencia Financiera de Colombia, con su respectivo valor.
2. En caso de que el crédito no sea suficiente para cancelar el total de la obligación con la entidad financiera, pagar la diferencia del saldo existente del crédito, si lo hubiere, por cuenta del empleado.
3. Cumplir con las especificaciones técnicas y legales del inmueble.
4. Asumir el valor del avalúo del inmueble, el cual será realizado por el perito que designe la Compañía.
5. Contar con un endeudamiento inferior al 42% del ingreso nominal, incluyendo la cuota de préstamo.
6. Ceder la hipoteca en primer grado a favor de Prebel S.A BIC.
7. Tomar seguro de vida y de vivienda a favor de Prebel S.A BIC, cuyo pago estará incluido en la cuota mensual. En caso de que el empleado o el inmueble sea rechazado por la aseguradora, la solicitud de crédito no será aprobado.

### [CRE-35] Crédito para préstamo de vivienda, reformas de vivienda, legalización de vivienda y pago de impuesto predial › ¿Cuáles son los requisitos para la escritura de adquisición del inmueble?

1. Certificado de tradición del inmueble con menos de 15 días de expedición.
2. Certificado original expedido por el acreedor hipotecario sobre la vigencia y cuantía del saldo que el solicitante le adeuda.

### [CRE-36] Crédito para préstamo de vivienda, reformas de vivienda, legalización de vivienda y pago de impuesto predial › ¿Cuáles son los requisitos para el pago del impuesto predial?

1. Cuantía máxima: 5 SMLMV al momento de la preaprobación por el Comité de Crédito del Fondo de crédito para vivienda.
2. Plazo: 3 años.

3. Intereses: 6% efectivo anual.
4. Garantía: Suscripción de pagaré y pignoración de primas.
5. Factura de la deuda del impuesto predial con vigencia no mayor a 3 años.
6. Certificado de tradición del inmueble no mayor a 15 días de expedición.
7. En caso de que la propiedad sea del cónyuge o compañero permanente, aportar registro civil de matrimonio o extra-juicio respectivamente.
8. Entregar al proceso de Bienestar dentro de los 30 días siguientes al desembolso los soportes correspondientes del pago realizado.

### [CRE-37] Crédito para préstamo de vivienda, reformas de vivienda, legalización de vivienda y pago de impuesto predial › ¿A quién me puedo dirigir para presentarle mi solicitud de crédito de vivienda, reformas de vivienda, legalización de vivienda y pago de impuesto predial?

Puedes contactarte con Stefanny Pulgarín Correa, Analista de Bienestar y RSE.

Teléfono: 3104057760

Correo: stefanny.pulgarin@prebel.com.co

### [CRE-38] Crédito para préstamo de vivienda, reformas de vivienda, legalización de vivienda y pago de impuesto predial › ¿Cuánto tarda el proceso de aprobación del crédito de vivienda, reformas de vivienda, legalización de vivienda y pago de impuesto predial?

Una vez presentados todos los documentos, el proceso de aprobación puede variar de acuerdo con cada caso, puedes consultar a Stefanny Pulgarín al 3104057760 para resolver tu inquietud.

***

### [CRE-39] Crédito para préstamo de vivienda, reformas de vivienda, legalización de vivienda y pago de impuesto predial › ¿Cuánto tiempo de antigüedad debo tener en la compañía para poder acceder a los créditos que otorga la compañía?

Mínimo el colaborador debe contar con 6 meses de antigüedad.

### [CRE-40] Crédito para préstamo de vivienda, reformas de vivienda, legalización de vivienda y pago de impuesto predial › ¿Quién es la persona de Gestión Humana que me puede ayudar con la solicitud de un crédito?

Puedes contactarte con Stefanny Pulgarín Correa, Analista de Bienestar y RSE.

Teléfono: 3104057760

Correo: stefanny.pulgarin@prebel.com.co

## Auxilios y beneficios (Auxilios_y_beneficios_Prebel_20260310.md, 10/03/2026)

### [AUX-01] Auxilios educativos o bonos de desarrollo

Es un auxilio que aplica para el empleado y sus hijos. Los pagos anuales se cancelan 50% en febrero y 50% en julio; se debe tener vinculación directa con Prebel a la fecha de generación del pago.

• Requisitos del auxilio educativo o bono de desarrollo:
Primaria, Preescolar y Secundaria:
1. Se debe presentar el certificado de estudios, calificaciones del año anterior, registro de nacimiento del menor, (en el caso de hijastros anexar declaración extra juicio de dependencia económica no superior a 30 días).
2. Se presentan los documentos una sola vez al año para pago en febrero y julio.

• Requisitos del auxilio para estudios de técnicos:
1. En caso de que sea el empleado el que lo solicite, se debe presentar certificación de estudio actual o liquidación de matrícula cancelada.
2. En caso de que la solicitud del auxilio sea para los hijos presentar certificación de estudio actual o liquidación de matrícula cancelada y registro de nacimiento.
3. En caso de que la solicitud del auxilio sea para hijastros presentar certificación de estudio actual o liquidación de matrícula cancelada y declaración extra juicio de dependencia económica no superior a 30 días.
4. Para hijos mayores de 18 años y menores de 25 años también se debe entregar declaración extra juicio de dependencia económica no superior a 30 días.
5. Se presenta los documentos cada semestre para pago en febrero y julio.
6. La institución educativa debe estar avalada por el Ministerio de Educación.

• Requisitos del auxilio para estudios de tecnología o universidad:
1. En caso de que sea el empleado el que lo solicite presentar certificación de estudio actual o liquidación de matrícula cancelada.
2. En caso de que la solicitud del auxilio sea para hijos presentar certificación de estudio actual o liquidación de matrícula cancelada y registro de nacimiento, (en el caso de hijastros anexar declaración extra juicio de dependencia económica no superior a 30 días).
3. Para hijos mayores de 18 años y menores de 25 años, también se debe entregar declaración extra-juicio de dependencia económica no superior a 30 días.
4. Se presentan los documentos cada semestre para pago en febrero y julio.

• Requisitos del auxilio para estudios de hijos con educación especial (discapacidad):
1. Para hijos presentar certificación de estudio actual, registro de nacimiento y calificación de discapacidad.
2. Para hijastros presentar certificación de estudio actual, registro de nacimiento, calificación de discapacidad y declaración extra juicio de dependencia económica no superior a 30 días.
3. Se presenta los documentos una sola vez al año para pago en febrero y julio.

• Valor del auxilio para primaria y preescolar: $497.000 en el año.

• Valor del auxilio para secundaria: $568.000 en el año.
• Valor del auxilio para estudios técnicos: $215.000 semestral.
• Valor del auxilio para tecnología: $282.000 semestral.
• Valor del auxilio para universidad: $298.000 semestral.
• Valor del auxilio para hijos con educación especial (discapacidad): $553.000 en el año.

### [AUX-02] Auxilio de incapacidad

Beneficia al colaborador durante una incapacidad médica. Este equivale al valor del salario básico mensual, que no cubre el subsidio económico de la EPS. Aplica hasta por dos eventos en el año el día 180 de la incapacidad.

• Requisitos del auxilio de incapacidad:
1. El certificado de incapacidad debe presentarse a la compañía dentro de los 3 días hábiles siguientes a su expedición por parte de la EPS.
2. El reporte de las incapacidades se debe de realizar de la siguiente manera:

    o PA: Reportar a la opción de la Prebelnet de Reporte de Incapacidade
    o PO: Reportar al correo de incapacidades@prebel.com.co
    o PI: Reportar al WhatsApp Corporativo 3104589490
    o PP: Reportar al correo lucia.mejias@prebel.com.co

### [AUX-03] Beneficio: Atención de Emergencias (EMI)

Servicio médico en caso de emergencias para los empleados que prestan sus servicios en sede Productora, Comercial y Rionegro (en caso de requerirlo contáctate con un brigadista y este te apoyará con la gestión de la emergencia).

### [AUX-04] Beneficio: Seguro de vida o invalidez

En caso de muerte o invalidez del empleado, sus beneficiarios recibirán una suma correspondiente a 6 veces su salario. Si el empleado no es aceptado por la compañía de seguros dentro de la póliza, se tomará por lo menos una que asegure muerte e incapacidad y cuyo origen sea por accidente.

• Requisitos del seguro de vida o invalidez:
1. Se requiere vinculación laboral al momento del fallecimiento del empleado y/o expedición de la resolución de invalidez por parte del Fondo de pensiones.

### [AUX-05] Auxilio visual u odontológico

Beneficia a todos los colaboradores y su grupo familiar (cónyuge o compañero permanente, padres e hijos) en la compra de anteojos, lentes de contacto, cirugías visuales, citas y/o tratamientos odontológicos.

• Condiciones del Auxilio visual u odontológico:
1. Este beneficio podrá usarse una sola vez a año calendario.
• Requisitos del Auxilio para temas visuales:
1. Copia de la fórmula medica de la EPS y factura de venta cancelada de la EPS u óptica particular.

2. Para el pago del auxilio por medio de las ópticas de convenio por el Fondo de Empleados, presentar copia de la fórmula médica y factura de venta, ambas de las ópticas con las que se tenga el convenio vigente.
3. Para el pago del auxilio por cirugía visual debe presentar copia de la historia clínica y factura de venta cancelada.
4. Si el auxilio es para el grupo familiar del colaborador, debe presentar documento que valide parentesco como lo es: el registro civil de nacimiento, matrimonio o declaración juramentada de convivencia no mayor a 30 días.
* Requisitos del Auxilio para temas odontológicos:
   1. Presentar factura de venta cancelada.
   2. Descripción del procedimiento.
   3. RUT de cualquier entidad o especialista tratante que preste el servicio y/o las entidades con convenio vigente en el Fondo de Empleados.
   4. Si el auxilio es para el grupo familiar del colaborador, debe presentar documento que valide parentesco como lo es: el registro civil de nacimiento, matrimonio o declaración juramentada de convivencia no mayor a 30 días.
* Valor del auxilio visual u odontológico: $332.000.

### [AUX-06] Auxilio de alimentación para empleados en sede

Tiene como propósito apalancar la salud y el bienestar de los colaboradores, a través de un servicio de alimentación para cada turno de trabajo. Aplica para las personas que trabajen en las sedes Productora, Comercial y Rionegro.

* Condiciones del Auxilio de alimentación para empleados en sede: el pago por el servicio dependerá del rango salarial del colaborador:
   1. Hasta 2 SMMLV – 10% costo servicio
   2. 2 a 5 SMMLV – 15% costo servicio
   3. 5 a 7 SMLVM - el 50% costo servicio
   4. 7 a 9 SMLVM -el 70% costo servicio
   5. 9 en adelante - el 88% costo servicio

Nota: Si el colaborador realizó la solicitud de alimentación y no la consume, se cobrará el 100% del costo del servicio.

### [AUX-07] Auxilio de alimentación (personal Impulso y Mercadeo)

Diseñado para las colaboradoras de Impulso y Mercadeo; este es directamente proporcional al tiempo trabajado y se clasifica en los siguientes montos:

* Mercaconsultoras y transferencistas: $56.000 mensual.
* Consultoras: $22.000 mensual.

### [AUX-08] Beneficio: programas de salud mental

1. Desahogadero: espacio gratuito de 45 minutos, en donde el colaborador será escuchado por un especialista de manera presencial (1 vez al mes).

### [AUX-09] Beneficio: programas de salud mental › ¿Cómo acceder al espacio de Desahogadero?

Escribe al proceso de Bienestar (+57 3104057760), manifestando tu interés por participar del programa y adjunta los siguientes datos para la programación de la cita: nombre, cc, área a la que pertenece, sede y teléfono de contacto.

2. **Red de amor:** asesoría psicológica a través de la línea de atención (604 3607080 opc 3), esta es una línea atendida por especialistas y es un beneficio que se extiende al grupo familiar del colaborador (padres, cónyuge o compañero permanente, hijos). El colaborador podrá acceder hasta 5 sesiones.

### [AUX-10] Auxilio de salud mental

Cubre a los familiares del colaborador (padres, cónyuge o compañero permanente e hijos) y busca apoyar la atención o requerimientos relacionados con la salud mental. Este auxilio podrá usarse una sola vez a año calendario.

• Requisitos del auxilio de salud mental:
1. Factura del servicio.
2. Copia de la tarjeta profesional del especialista o RUT (sea persona natural o jurídica).
3. En caso de uso para hijos: copia del registro de nacimiento.
4. Para los padres del empleado: copia de cédula de ciudadanía y registro civil de nacimiento del empleado.
5. En caso de uso para cónyuge o compañero permanente: copia de la cédula y certificado de matrimonio o extra juicio no mayor a 30 días.
• Valor del auxilio de salud mental: $332.000

### [AUX-11] Auxilio para brigadistas o emisores de seguridad

Este auxilio reconoce el servicio que ofrecen los brigadistas y emisores de seguridad al interior de la compañía y será proporcional a la asistencia efectiva de cada uno de los entrenamientos programados.

• Valor del auxilio para Brigadistas: $87.000
• Valor del auxilio para Emisores de seguridad: $174.000

### [AUX-12] Auxilio de nacimiento, adopción y/o aborto

Beneficia al colaborador (padre o madre) con ocasión del nacimiento o adopción legal de su hijo. Este auxilio aplica hasta 3 hijos, durante el tiempo de labor en la compañía.

• Requisitos del auxilio de nacimiento, adopción y/o aborto:
1. En el caso de nacimiento entregar a Nómina el registro civil.
2. En caso de adopción entregar a Nómina sentencia de un juez de familia que decrete la adopción legal.
3. En caso de aborto, entregar a Nómina el acta de defunción fetal o constancia de la EPS.
• Valor del auxilio por nacimiento o adopción: $418.000
• Valor del auxilio por aborto: $ 206.000

### [AUX-13] Auxilio de matrimonio

El colaborador o colaboradora que contraiga matrimonio bien sea civil o religioso en Colombia, recibirá: 7 días calendario de permiso remunerado a partir del día del evento.

• Requisitos del Auxilio de matrimonio:
1. El empleado comunicara con no menos de 8 días de anticipación al jefe inmediato la fecha del matrimonio, el cual debe reportar al área de nómina la licencia.
2. Se reconocerá una sola vez durante el vínculo laboral.

3. Presentar registro civil o eclesiástico de matrimonio.

### [AUX-14] Auxilio por pensión de vejez o invalidez

Al momento de recibir la resolución de pensión, se pagará junto con la liquidación de prestaciones sociales, un auxilio equivalente a 30 días de salario básico.

• Condiciones del Auxilio por pensión de vejez o invalidez:
1. Para los colaboradores que tengan comisiones, será de 30 días de salario promedio en los últimos 3 meses.
2. Se pagará junto con la liquidación de prestaciones sociales.
• Requisitos del Auxilio por pensión de vejez o invalidez:
1. Presentar Resolución de pensión de vejez o invalidez.
2. Presentar carta de renuncia, con fecha no inferior a 15 días.

### [AUX-15] Auxilio por muerte o invalidez del colaborador

En caso de:

• Muerte o invalidez total del colaborador que gane menos de 3 SMLV: se le entregará a los familiares el valor total de $4.063.000.

• Muerte o invalidez total del empleado que gane más de 3 SMLV: se le entregará a los familiares el valor total de $2.823.000.

Se entregará a los beneficiarios por ley junto con la liquidación de prestaciones legales.

### [AUX-16] Auxilio por muerte de familiares directos

En caso de:

• Muerte del cónyuge, compañera (o) permanente e hijos: se le entregará al colaborador el valor total de $1.809.000.

• Muerte de padres o hermanos: se le entregará al colaborador el valor total de $1.132.000.

Para hacer efectivo este auxilio, el colaborador deberá entregar a Nómina el acta de defunción del familiar en cuestión.

### [AUX-17] Auxilio por muerte de familiares directos › ¿A quién puedo solicitar información sobre los auxilios que ofrece la compañía?

Puedes solicitar información a Stefanny Pulgarín, Analista de Bienestar y RSE, al 3104057760 o puedes consultar, según el público al que perteneces, al proceso de nómina:

Personal Administrativo: Shirley Silgado.

Personal Operativo: Yasmín Yepes.

Personal Impulso y Mercadeo: Lucía Mejía.

Personal Practicante: Lucía Mejía.

### [AUX-18] Auxilio por muerte de familiares directos › ¿A quién puedo solicitar información sobre los beneficios que ofrece la compañía?

Puedes solicitar información a Stefanny Pulgarín, Analista de Bienestar y RSE, al 3104057760

## Glosario Business Partner (Glosario_Business_Partner_20260922.md, 22/09/2026)

### [GLO-01] Business Partner de Gestión Humana

Es el aliado estratégico del negocio, quien entiende las necesidades de la organización y las traduce en soluciones de talento que contribuyen al cumplimiento de los objetivos corporativos. Acompaña y participa en la toma de decisiones, asesora a los líderes, impulsa el desarrollo del talento, gestiona el cambio organizacional y promueve una cultura de alto desempeño. Su propósito es asegurar que la estrategia de personas esté alineada con la estrategia del negocio.

En Prebel contamos con dos personas en este cargo:

### [GLO-02] Business Partner de Gestión Humana › Nathalia León

- Nathalia León: quien acompaña a todo el personal de Sede Productora y Sede Rionegro.

### [GLO-03] Business Partner de Gestión Humana › Laura Jaramillo

- Laura Jaramillo: quien acompaña a todo el personal de Sede Comercial y quienes se encuentran fuera de sede.

### [GLO-04] Accidente de trabajo

Es todo suceso repentino que ocurre por causa o con ocasión del trabajo y que produce en el trabajador una lesión orgánica, una perturbación funcional o psicológica, una invalidez o, en los casos más graves, la muerte. También es:

- Aquel que se produce durante la ejecución de órdenes del empleador, o contratante durante la ejecución de una labor bajo su autoridad, aún fuera del lugar y horas de trabajo.

- El que se produzca por la ejecución de actividades recreativas, deportivas o culturales, cuando se actúe por cuenta o en representación del empleador o de la empresa usuaria cuando se trate de trabajadores de empresas de servicios temporales que se encuentren en misión.

Tu misión: reportar oportunamente a la BP o al personal de SST cuando se presenten presuntos accidentes de trabajo, participar activamente de la investigación y ser un embajador del cuidado y la seguridad para ti y tus compañeros.

### [GLO-05] Incidente de trabajo

Es un evento relacionado con la actividad laboral que no genera lesiones ni daños a la salud del trabajador, pero que tuvo el potencial de ocasionarlos.

Los incidentes constituyen una fuente valiosa de aprendizaje, ya que permiten identificar condiciones o comportamientos inseguros antes de que se materialice un accidente. Su reporte y análisis fortalecen la cultura de prevención y la mejora continua en seguridad y salud en el trabajo.

Tu misión: reportar a la BP o al personal de SST cuando se presenten incidentes de trabajo e identificar situaciones que puedan representar un riesgo para el personal.

### [GLO-06] Ausentismo

es la ausencia del trabajador de su puesto de trabajo durante la jornada laboral. El ausentismo es un indicador estratégico de la salud organizacional, ya que impacta la productividad, los costos, el clima laboral y la continuidad operativa. Su análisis permite identificar tendencias, causas raíz y diseñar estrategias preventivas enfocadas en bienestar, liderazgo y compromiso de los colaboradores.

Dentro del ausentismo, podemos encontrar las siguientes causas:

### [GLO-07] Ausentismo › Licencia remunerada

- Licencia remunerada: es la autorización otorgada por el empleador para que el trabajador se ausente temporalmente de sus labores, manteniendo el derecho al pago de su salario y demás beneficios que correspondan durante el período autorizado. En Prebel, el jefe directo está autorizado a otorgar al colaborador hasta un (1) día de permiso remunerado, en caso de que sean más días, se deberá contar con la autorización de la Business Partner.

### [GLO-08] Ausentismo › Licencia no remunerada

- Licencia no remunerada: es la autorización concedida por el empleador para que el trabajador se ausente temporalmente de sus funciones, sin que exista obligación de pagar salario durante el tiempo de la licencia, salvo disposición legal o acuerdo diferente entre las partes. En Prebel, el jefe directo está autorizado a otorgar al colaborador hasta un (1) día de permiso no remunerado y en caso de que sean más días, se deberá contar con la autorización de la Business Partner.

### [GLO-09] Ausentismo › Licencia de maternidad

- Licencia de maternidad: derecho que tiene la colaboradora gestante a disfrutar de un período de descanso remunerado con ocasión del embarazo y el nacimiento de su hijo, con el fin de proteger la salud de la madre, favorecer la recuperación posparto y garantizar el cuidado del recién nacido.

En Colombia, la licencia tiene una duración de 18 semanas remuneradas, las cuales pueden iniciar una o dos semanas antes de la fecha probable del parto, según recomendación médica. El reconocimiento económico está a cargo de la EPS, siempre que se cumplan los requisitos establecidos por la normatividad vigente. Como líder, tu deber es informar oportunamente a Gestión Humana cuando alguna persona de tu equipo se encuentre en estado de gestación.

### [GLO-10] Ausentismo › Licencia de paternidad

- Licencia de paternidad: derecho que tiene el padre trabajador a disfrutar de un período de descanso remunerado con ocasión del nacimiento o adopción de un hijo, promoviendo la corresponsabilidad en el cuidado del menor y el fortalecimiento del vínculo familiar.

En Colombia, la licencia de paternidad corresponde actualmente a dos (2) semanas remuneradas, siempre que el trabajador cumpla con los requisitos establecidos por la legislación y el reconocimiento económico sea autorizado por la EPS.

### [GLO-11] Ausentismo › Licencia de luto

- Licencia de luto: derecho que tiene el trabajador a ausentarse de sus labores con ocasión del fallecimiento de determinados familiares, sin que ello afecte su salario ni sus prestaciones sociales. Su finalidad es permitir que el colaborador afronte el duelo y atienda las diligencias derivadas del fallecimiento de su ser querido. En Colombia, la licencia por luto corresponde a cinco (5) días hábiles remunerados a partir del día de la muerte. Este derecho aplica en caso de fallecimiento del cónyuge o compañero(a) permanente, así como de familiares hasta el segundo grado de consanguinidad (padres, hijos, hermanos, abuelos y nietos), primer grado de afinidad (suegros) y primer grado civil (padres e hijos).

Tu misión como líder es informar de manera oportuna a la Business Partner cuando se presente el fallecimiento con el fin de poder activar la novedad en nómina y el acompañamiento por parte de la compañía.

### [GLO-12] Ausentismo › Suspensión de contrato

- Suspensión de contrato: es la interrupción temporal de las principales obligaciones derivadas de la relación laboral, sin que ello implique la terminación del contrato. Durante la suspensión, el trabajador deja de prestar sus servicios y el empleador no está obligado a pagar salario, salvo las excepciones previstas por la ley. La decisión de suspender el contrato de trabajo no está en cabeza del jefe directo, sino que primero se debe agotar un proceso disciplinario liderado por la Business Partner, donde dependiendo de muchos factores, se podrá emitir como decisión la suspensión del contrato.

### [GLO-13] Ausentismo › Incapacidades

- Incapacidades: puede ser por enfermedad común, enfermedad profesional o accidente de trabajo. Solo se acepta la incapacidad emitida por la EPS o ARL.

### [GLO-14] Onboarding

es el proceso estructurado de integración mediante el cual un nuevo colaborador adquiere los conocimientos, herramientas, relaciones y competencias necesarias para desempeñar su cargo de manera efectiva y adaptarse a la cultura organizacional.

Un proceso de onboarding exitoso va más allá de la inducción inicial; facilita la adaptación, acelera la productividad, fortalece el compromiso y reduce la rotación temprana. Como colaboradores, debemos acompañar este proceso asegurando que la experiencia de ese colaborador nuevo sea positiva desde su ingreso y esté alineada con la propuesta de valor de la organización.

### [GLO-15] Proceso Disciplinario

Es el procedimiento mediante el cual se analiza un posible incumplimiento por parte de un colaborador, garantizando su derecho a la defensa y al debido proceso. Dependiendo del análisis del caso, puede finalizar sin sanción, con llamado de atención, suspensión o, cuando corresponda, terminación del contrato de trabajo.
Como líder, tu misión es reportar oportunamente a la Business Partner cualquier posible incumplimiento y entregar las pruebas disponibles. Recuerda que debemos actuar bajo el principio de inmediatez y cumplir los tiempos establecidos por la ley, incluyendo el término mínimo de cinco (5) días hábiles para que el colaborador conozca las pruebas y ejerza su derecho de defensa.

### [GLO-16] Espacio de concertación

Espacio de compañía en el cual se realiza una retroalimentación al colaborador y se diligencia un acta de compromiso. Como líder, estás en la capacidad de realizar este espacio autónomamente, sin embargo, tu misión es siempre entregar a la Business Partner el acta debidamente diligenciada y firmada.

### [GLO-17] Grupos Primarios

Son espacios de conexión organizacional en los que los gerentes corporativos comparten con los colaboradores los principales retos, logros, metas y novedades de sus áreas. Además, se promueve el reconocimiento de personas y equipos que representan los valores corporativos, fortaleciendo la cultura organizacional.

Como líder, tu misión es programar una reunión con tu equipo cada dos meses para visualizar los Grupos Primarios y desarrollar las actividades propuestas en la Caja de la Cultura, fomentando la comunicación, el alineamiento estratégico y el fortalecimiento de nuestros valores.

### [GLO-18] Pacto Colectivo

Es un acuerdo celebrado entre Prebel y sus trabajadores, mediante el cual se establecen beneficios y condiciones extralegales aplicables durante su vigencia. Sus beneficios están orientados principalmente a cuatro frentes: salud, educación, momentos especiales y créditos, buscando contribuir al bienestar de los colaboradores y sus familias. De acuerdo con su naturaleza y lo establecido en el Pacto, estos beneficios podrán tener carácter no salarial en los términos permitidos por la ley.

### [GLO-19] GPS

Proceso mediante el cual se valoran las competencias corporativas y el nivel de cumplimiento de los objetivos individuales definidos para cada colaborador. Este proceso se desarrolla en dos momentos durante el año: (i) entre los meses de febrero y marzo, se realiza la evaluación de las competencias y del cumplimiento de los objetivos correspondientes al año inmediatamente anterior; y (ii) entre los meses de julio y agosto, se efectúa el seguimiento al avance y cumplimiento de los objetivos establecidos para la vigencia en curso, con el fin de identificar oportunidades de mejora y orientar el logro de los resultados esperados.

### [GLO-20] Guion de lideres

es un medio de comunicación interna orientado a fortalecer la claridad organizacional y garantizar que la información relevante llegue de manera oportuna a todo el personal operativo y de impulso y mercadeo de la empresa. Consiste en un documento en formato PDF que se distribuye semanalmente y reúne noticias, novedades, campañas, lineamientos e información de interés que impacta o aplica a estos públicos. Es responsabilidad de los lideres socializarlo con su equipo de trabajo, promoviendo espacios de comunicación que aseguran la comprensión de los mensajes, alinean a los colaboradores con las prioridades de la organización y fortalecen el conocimiento sobre las iniciativas y eventos más importantes de la compañía.
