/* Isa · inicio + perfil + chat (pantalla completa o widget). Sin dependencias. */
(() => {
  const $ = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => [...r.querySelectorAll(s)];
  const guardar = (k, v) => { try { v === null ? localStorage.removeItem("isa." + k) : localStorage.setItem("isa." + k, JSON.stringify(v)); } catch {} };
  const leer = (k, d = null) => { try { const v = localStorage.getItem("isa." + k); return v ? JSON.parse(v) : d; } catch { return d; } };
  const WIDGET = document.documentElement.dataset.vista === "widget";

  const TIPOS = { operativo: "Operativo", impulso: "Impulso y mercado", administrativo: "Administrativo", nose: "Sin definir" };
  const SEDES = { productora: "Sede Productora", rionegro: "Sede Rionegro", comercial: "Sede Comercial", fuera: "Fuera de sede", nose: "" };

  // Contactos tomados literalmente de los documentos oficiales.
  const CONTACTOS = [
    { rol: "Bienestar, auxilios y créditos", nombre: "Stefanny Pulgarín", tel: "3104057760", mail: "stefanny.pulgarin@prebel.com.co" },
    { rol: "Certificados · operativo", nombre: "Angela Quintero", tel: "3234830720", mail: "Angela.quintero@prebel.com.co", tipos: ["operativo"] },
    { rol: "Certificados · impulso y administrativo", nombre: "Michell Román", tel: "3147710112", mail: "michell.roman@prebel.com.co", tipos: ["impulso", "administrativo"] },
    { rol: "Business Partner · Productora y Rionegro", nombre: "Nathalia León", sedes: ["productora", "rionegro"] },
    { rol: "Business Partner · Comercial y fuera de sede", nombre: "Laura Jaramillo", sedes: ["comercial", "fuera"] },
  ];
  const bpDe = (sede) => CONTACTOS.find((c) => c.sedes?.includes(sede));

  const TEMAS = {
    vin: { i: "🧾", t: "Nómina", c: "var(--azul-prebel)", p: ["¿Cómo pido mi certificado laboral?", "¿Cómo retiro cesantías para vivienda?", "¿Cuántos días de vacaciones tengo?", "¿Qué hago con una incapacidad?"] },
    cre: { i: "💳", t: "Créditos", c: "var(--verde)", p: ["¿Qué créditos ofrece Prebel?", "¿Requisitos del crédito de vivienda?", "¿Qué es el crédito de mascotas?", "¿Qué antigüedad necesito?"] },
    aux: { i: "🎁", t: "Auxilios", c: "var(--coral)", p: ["¿Cuánto es el auxilio educativo?", "¿Cómo funciona el auxilio visual?", "¿Hay auxilio de matrimonio?", "¿Cómo accedo a salud mental?"] },
    glo: { i: "🤝", t: "Mi BP", c: "var(--celeste)", p: ["¿Quién es mi Business Partner?", "¿Qué hago si tengo un accidente?", "¿Qué es la licencia de luto?", "¿Qué es el pacto colectivo?"] },
  };

  let perfil = leer("perfil", null);
  let chat = leer("chat", []); // [{q:"isa"|"yo", t, f:[{id,etiqueta}], s:[...], k?:"contactos"}]
  let modoLiteral = false, ocupado = false, fuentesCache = null, numeroWa = null;

  /* ---------------------------------------------------------------- navegación */
  const PANTALLAS = ["p-inicio", "p-perfil", "p-chat"];
  function ir(id) {
    PANTALLAS.forEach((p) => ($("#" + p).hidden = p !== id));
    cerrarMenu();
    if (id === "p-chat") { pintarPerfil(); pintarChat(); if (!matchMedia("(pointer: coarse)").matches) setTimeout(() => $("#txt").focus(), 50); }
    else { const h = $("#" + id + " h1, #" + id + " h2"); if (h) { h.tabIndex = -1; h.focus({ preventScroll: true }); } }
    window.scrollTo(0, 0);
  }
  const saludoHora = () => { const h = new Date().getHours(); return h < 12 ? "Buenos días" : h < 19 ? "Buenas tardes" : "Buenas noches"; };
  $("#saludoHora").textContent = saludoHora() + (perfil ? ", qué bueno verte" : "");
  const entrar = () => ir(perfil ? "p-chat" : "p-perfil");
  $("#btnEmpezar").addEventListener("click", entrar);
  $("#btnInicio").addEventListener("click", () => ir("p-inicio"));
  $("#btnVolverPerfil").addEventListener("click", () => ir(perfil ? "p-chat" : "p-inicio"));

  /* ---------------------------------------------------------------- perfil */
  const sel = { tipo: perfil?.tipo || null, sede: perfil?.sede || null };
  const marcar = (cont, attr, val) => $$("button", cont).forEach((b) => b.setAttribute("aria-checked", String(b.dataset[attr] === val)));
  const revisar = () => ($("#btnPerfil").disabled = !(sel.tipo && sel.sede));
  $("#tipos").addEventListener("click", (e) => { const b = e.target.closest("button"); if (b) { sel.tipo = b.dataset.tipo; marcar($("#tipos"), "tipo", sel.tipo); revisar(); } });
  $("#sedes").addEventListener("click", (e) => { const b = e.target.closest("button"); if (b) { sel.sede = b.dataset.sede; marcar($("#sedes"), "sede", sel.sede); revisar(); } });
  function cargarSeleccion() { sel.tipo = perfil?.tipo || null; sel.sede = perfil?.sede || null; marcar($("#tipos"), "tipo", sel.tipo); marcar($("#sedes"), "sede", sel.sede); revisar(); }
  cargarSeleccion();
  $("#btnPerfil").addEventListener("click", () => {
    const antes = perfil;
    perfil = { tipo: sel.tipo, sede: sel.sede };
    guardar("perfil", perfil);
    if (antes && chat.length && (antes.tipo !== perfil.tipo || antes.sede !== perfil.sede))
      agregar({ q: "isa", t: `Listo, ahora respondo para **${etiquetaPerfil()}**.` });
    ir("p-chat");
    actualizarWa();
  });
  const etiquetaPerfil = () => [TIPOS[perfil.tipo], SEDES[perfil.sede]].filter(Boolean).join(" · ");
  function pintarPerfil() { if (perfil) $("#perfilTxt").textContent = etiquetaPerfil(); }

  /* ---------------------------------------------------------------- render */
  const conv = $("#conversacion");
  const bajar = () => requestAnimationFrame(() => (conv.scrollTop = conv.scrollHeight));
  const esc = (s) => String(s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]);
  function inline(s) {
    return esc(s)
      .replace(/\*\*(.+?)\*\*/g, "<strong>$1</strong>")
      .replace(/(^|[\s(])\*(?!\s)(.+?)\*(?=[\s).,:;!?]|$)/g, "$1<em>$2</em>")
      .replace(/([\w.+-]+@[\w-]+\.[\w.]+\w)/g, '<a href="mailto:$1">$1</a>')
      .replace(/\b(3\d{9})\b/g, '<a href="tel:+57$1">$1</a>');
  }
  function md(texto) {
    let html = "", lista = null;
    const cerrar = () => { if (lista) { html += `</${lista}>`; lista = null; } };
    for (const l of String(texto).replace(/\r/g, "").split("\n")) {
      const ul = l.match(/^\s*(?:[-•*]|\[ \])\s+(.*)/), ol = l.match(/^\s*(\d+)[.)]\s+(.*)/);
      if (ul) { if (lista !== "ul") { cerrar(); html += "<ul>"; lista = "ul"; } html += `<li>${inline(ul[1])}</li>`; }
      else if (ol) { if (lista !== "ol") { cerrar(); html += `<ol start="${ol[1]}">`; lista = "ol"; } html += `<li>${inline(ol[2])}</li>`; }
      else if (!l.trim()) cerrar();
      else { cerrar(); html += `<p>${inline(l)}</p>`; }
    }
    cerrar();
    return html;
  }
  function nodo(quien) {
    const m = document.createElement("div");
    m.className = "msg " + quien;
    m.innerHTML = quien === "isa" ? `<img class="av" src="isa.svg" alt=""><div class="burbuja"></div>` : `<div class="burbuja"></div>`;
    conv.appendChild(m);
    return m;
  }
  function pintarMensaje(e) {
    const m = nodo(e.q);
    const b = $(".burbuja", m);
    if (e.q === "yo") { b.textContent = e.t; return m; }
    b.innerHTML = md(e.t);
    if (e.k === "contactos") pintarContactos(b);
    if (e.v) b.insertAdjacentHTML("beforeend", `<p class="aviso-validador">✔ Te muestro el texto oficial para no darte un dato impreciso.</p>`);
    if (e.r) pintarPie(b, e);
    if (e.s?.length) pintarSugerencias(m, e.s, e.lit);
    return m;
  }
  function agregar(e) { chat.push(e); chat = chat.slice(-40); guardar("chat", chat); const m = pintarMensaje(e); bajar(); return m; }
  function pintarChat() {
    conv.innerHTML = "";
    bienvenida();
    chat.forEach(pintarMensaje);
    bajar();
  }
  function bienvenida() {
    const bp = bpDe(perfil?.sede);
    let t = `${saludoHora()} 👋 ¿En qué te ayudo?`;
    if (bp) t += `\n\nTu Business Partner es **${bp.nombre}**.`;
    pintarMensaje({ q: "isa", t });
    const cont = document.createElement("div");
    cont.className = "tarjetas-tema";
    for (const [k, v] of Object.entries(TEMAS)) {
      const b = document.createElement("button");
      b.className = "tema"; b.style.setProperty("--c", v.c);
      b.innerHTML = `<span aria-hidden="true">${v.i}</span>${v.t}`;
      b.addEventListener("click", () => mostrarTema(k));
      cont.appendChild(b);
    }
    conv.appendChild(cont);
  }
  function mostrarTema(k) {
    const v = TEMAS[k];
    agregar({ q: "yo", t: v.t });
    agregar({ q: "isa", t: "Preguntas frecuentes:", s: v.p });
  }
  function pintarContactos(burbuja) {
    const cont = document.createElement("div");
    cont.className = "contactos";
    for (const c of CONTACTOS) {
      const tuyo = c.tipos?.includes(perfil?.tipo) || c.sedes?.includes(perfil?.sede);
      const d = document.createElement("div");
      d.className = "contacto" + (tuyo ? " tuyo" : "");
      d.innerHTML = `<div class="rol">${esc(c.rol)}${tuyo ? " · tuyo" : ""}</div><b>${esc(c.nombre)}</b>` +
        (c.tel ? `<a href="tel:+57${c.tel}">📞 ${c.tel}</a>` : "") + (c.mail ? `<a href="mailto:${c.mail}">✉️ Correo</a>` : "");
      cont.appendChild(d);
    }
    burbuja.appendChild(cont);
  }
  function pintarPie(burbuja, e) {
    const pie = document.createElement("div");
    pie.className = "pie-msg";
    for (const x of e.f || []) {
      const corto = x.etiqueta.split(" › ").slice(0, 2).join(" › ");
      const el = document.createElement(x.id ? "button" : "span");
      el.className = "fuente";
      el.textContent = "📄 " + (corto.length > 48 ? corto.slice(0, 46) + "…" : corto);
      if (x.id) { el.type = "button"; el.title = "Ver texto oficial: " + x.etiqueta; el.addEventListener("click", () => verFuente(x.id)); }
      pie.appendChild(el);
    }
    pie.insertAdjacentHTML("beforeend", `<span class="sep"></span><button class="mini" data-a="oir" aria-label="Escuchar">🔊</button><button class="mini" data-a="si" aria-pressed="false" aria-label="Me sirvió">👍</button><button class="mini" data-a="no" aria-pressed="false" aria-label="No me sirvió">👎</button>`);
    pie.addEventListener("click", (ev) => {
      const b = ev.target.closest(".mini"); if (!b) return;
      if (b.dataset.a === "oir") return leerEnVoz(e.t, true);
      $$("[data-a=si],[data-a=no]", pie).forEach((x) => x.setAttribute("aria-pressed", String(x === b)));
      const votos = leer("votos", []); votos.push({ v: b.dataset.a, t: Date.now() }); guardar("votos", votos.slice(-200));
      if (b.dataset.a === "no") agregar({ q: "isa", t: "Gracias por contarme. ¿Lo intentamos de otra forma o prefieres hablar con alguien?", s: ["Hablar con alguien"] });
    });
    burbuja.appendChild(pie);
  }
  function pintarSugerencias(m, sugs, literal) {
    const c = document.createElement("div");
    c.className = "sugerencias";
    sugs.forEach((s, i) => {
      const b = document.createElement("button");
      b.textContent = s;
      b.addEventListener("click", () => (s === "Hablar con alguien" ? mostrarContactos() : preguntar(literal ? String(i + 1) : s, literal ? s : null)));
      c.appendChild(b);
    });
    m.after(c);
  }
  function mostrarContactos() {
    agregar({ q: "yo", t: "Hablar con alguien" });
    agregar({ q: "isa", t: "Te pueden ayudar (resalté a quien te corresponde):", k: "contactos" });
  }
  async function verFuente(id) {
    try {
      fuentesCache ??= await (await fetch("fuentes.json")).json();
      const s = fuentesCache[id]; if (!s) return;
      $("#dlgTitulo").textContent = s.etiqueta;
      $("#dlgFecha").textContent = `Documento oficial de Gestión Humana · versión del ${s.fecha}`;
      $("#dlgTexto").textContent = s.texto.replace(/\*\*/g, "");
      $("#dlgFuente").showModal();
    } catch (e) { console.error(e); }
  }

  /* ---------------------------------------------------------------- preguntar */
  const historialApi = () => chat.filter((e) => e.r || e.q === "yo").slice(-10).map((e) => ({ rol: e.q === "yo" ? "user" : "assistant", texto: e.t }));

  async function preguntar(texto, mostrar = null) {
    texto = texto.trim();
    if (!texto || ocupado) return;
    ocupado = true;
    $("#enviar").disabled = true;
    const hist = historialApi();
    agregar({ q: "yo", t: mostrar || texto });
    const m = nodo("isa");
    const burbuja = $(".burbuja", m);
    burbuja.innerHTML = `<span class="escribiendo" aria-label="Isa está escribiendo"><i></i><i></i><i></i></span>`;
    bajar();
    $("#estado").textContent = "Escribiendo…";
    try {
      let e;
      if (!modoLiteral) e = await preguntarIA(texto, hist, burbuja);
      if (!e) e = preguntarLiteral(texto);
      m.remove();
      agregar(e);
      leerEnVoz(e.t);
    } catch (err) {
      console.error(err);
      m.remove();
      agregar({ q: "isa", t: (err?.visible || "Tuve un problema para responder. Intenta de nuevo.") , s: ["Hablar con alguien"] });
    } finally {
      ocupado = false;
      $("#enviar").disabled = false;
      $("#estado").textContent = modoLiteral ? "Gestión Humana · modo literal" : "Gestión Humana · Prebel";
    }
  }

  async function preguntarIA(texto, historial, burbuja) {
    const r = await fetch("api/chat", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ pregunta: texto, perfil, historial }) });
    if ([503, 404, 405].includes(r.status)) { activarModoLiteral(); return null; }
    if (!r.ok || !r.body) throw new Error("http " + r.status);
    const lector = r.body.getReader(), dec = new TextDecoder();
    let buf = "", bruto = "", fin = null;
    for (;;) {
      const { value, done } = await lector.read();
      if (done) break;
      buf += dec.decode(value, { stream: true });
      let i;
      while ((i = buf.indexOf("\n")) >= 0) {
        const linea = buf.slice(0, i); buf = buf.slice(i + 1);
        if (!linea.trim()) continue;
        const ev = JSON.parse(linea);
        if (ev.t === "delta") { bruto += ev.v; const c = bruto.indexOf("[["); burbuja.innerHTML = md(c >= 0 ? bruto.slice(0, c) : bruto); bajar(); }
        else if (ev.t === "fin") fin = ev;
        else if (ev.t === "error") throw Object.assign(new Error(ev.v), { visible: ev.v });
      }
    }
    if (!fin) throw new Error("respuesta incompleta");
    return { q: "isa", r: true, t: fin.reemplazo || fin.texto || bruto, f: fin.fuentes || [], s: fin.sugerencias || [], v: Boolean(fin.reemplazo && fin.fuentes?.length) };
  }

  // Motor literal de Valentina (sin IA): texto oficial tal cual, recortado de saludos y avisos.
  function preguntarLiteral(texto) {
    const LE = window.LocalEngine;
    if (!LE) return { q: "isa", t: "No pude cargar el motor de respaldo. Recarga la página." };
    const grupo = ["operativo", "administrativo", "impulso"].includes(perfil?.tipo) ? perfil.tipo : "";
    const a = LE.ask(texto, grupo);
    const t = (a.texto || "")
      .replace(/\n*📄[\s\S]*$/, "")
      .replace(/^¡Claro! Esto es lo que necesitas saber:\s*/, "")
      .replace(/\n*Si necesitas más detalles, aquí estoy para ayudarte\.?/g, "")
      .replace(/\n*_?Asistente de Gestión Humana con inteligencia artificial[\s\S]*$/, "")
      .replace(/\n\n(?:\*?\d+\.\*? .*\n?)+\n*Elige una opción[\s\S]*$/, "")
      .replace(/(^|\s)\*(?!\s)([^*\n]+?)\*/g, "$1**$2**")
      .replace(/(^|\s)_(?!\s)([^_\n]+?)_/g, "$1*$2*")
      .trim();
    const f = (a.fuentes || []).map((x) => ({ etiqueta: x.replace(/_\d{8}\.md/, "").replace(/_/g, " ").replace(" → ", " › ") }));
    return { q: "isa", r: a.estado === "ok", t: (a.aviso ? `⚠️ ${a.aviso}\n\n` : "") + t, f, s: (a.opciones || []).slice(0, 8), lit: true };
  }
  function activarModoLiteral() {
    if (modoLiteral) return;
    modoLiteral = true;
    $("#avisoModo").hidden = false;
    $("#avisoModo").textContent = "Modo sin IA: respondo con el texto literal de los documentos oficiales.";
  }

  /* ---------------------------------------------------------------- menú, widget y WhatsApp */
  const menu = $("#menu");
  function cerrarMenu() { menu.hidden = true; $("#btnMenu").setAttribute("aria-expanded", "false"); }
  $("#btnMenu").addEventListener("click", (e) => { e.stopPropagation(); menu.hidden = !menu.hidden; $("#btnMenu").setAttribute("aria-expanded", String(!menu.hidden)); });
  document.addEventListener("click", (e) => { if (!menu.hidden && !menu.contains(e.target)) cerrarMenu(); });
  menu.addEventListener("click", (e) => {
    const b = e.target.closest("[data-m]"); if (!b) return;
    cerrarMenu();
    if (b.dataset.m === "perfil") { cargarSeleccion(); ir("p-perfil"); }
    if (b.dataset.m === "nueva") { chat = []; guardar("chat", null); pintarChat(); }
    if (b.dataset.m === "salir") {
      chat = []; perfil = null; guardar("chat", null); guardar("perfil", null); cargarSeleccion();
      $("#saludoHora").textContent = saludoHora();
      if (WIDGET) { parent.postMessage("isa:cerrar", location.origin); ir("p-perfil"); } else ir("p-inicio");
    }
  });
  $("#btnCambiarPerfil").addEventListener("click", () => { cargarSeleccion(); ir("p-perfil"); });
  $("#btnExpandir").addEventListener("click", () => (window.parent !== window ? parent.postMessage("isa:expandir", location.origin) : null));
  $("#btnCerrar").addEventListener("click", () => parent.postMessage("isa:cerrar", location.origin));

  function actualizarWa() {
    const saludo = perfil && perfil.tipo !== "nose" ? `Hola Isa, soy ${TIPOS[perfil.tipo].toLowerCase()}${SEDES[perfil.sede] ? " de " + SEDES[perfil.sede] : ""}` : "Hola Isa";
    for (const a of [$("#btnWaInicio"), $("#btnWaBarra"), $("#menuWa")]) {
      if (numeroWa) { a.href = `https://wa.me/${numeroWa}?text=${encodeURIComponent(saludo)}`; a.removeAttribute("aria-disabled"); a.title = "Continuar por WhatsApp"; }
      else { a.removeAttribute("href"); a.setAttribute("aria-disabled", "true"); a.title = "La línea de WhatsApp de Isa estará disponible pronto"; }
    }
    if (!numeroWa && !$("#menuWa small")) $("#menuWa").insertAdjacentHTML("beforeend", "<small>pronto</small>");
  }
  for (const a of [$("#btnWaInicio"), $("#btnWaBarra"), $("#menuWa")])
    a.addEventListener("click", (e) => {
      if (numeroWa) return;
      e.preventDefault();
      if (!$("#p-chat").hidden) agregar({ q: "isa", t: "La línea de WhatsApp de Isa estará disponible muy pronto. Por ahora sigamos por aquí 🙂" });
      else a.innerHTML = '<svg><use href="#i-wa"/></svg>WhatsApp: muy pronto';
    });

  /* ---------------------------------------------------------------- formulario, voz y accesibilidad */
  const txt = $("#txt");
  txt.addEventListener("input", () => { txt.style.height = "auto"; txt.style.height = Math.min(txt.scrollHeight, 128) + "px"; });
  txt.addEventListener("keydown", (e) => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); $("#form").requestSubmit(); } });
  $("#form").addEventListener("submit", (e) => { e.preventDefault(); const v = txt.value; txt.value = ""; txt.style.height = "auto"; preguntar(v); });
  $("#temasRapidos").addEventListener("click", (e) => {
    const b = e.target.closest("button"); if (!b || ocupado) return;
    b.dataset.humano ? mostrarContactos() : mostrarTema(b.dataset.tema);
  });

  const Rec = window.SpeechRecognition || window.webkitSpeechRecognition;
  if (!Rec) $("#mic").hidden = true;
  else {
    let rec = null;
    $("#mic").addEventListener("click", () => {
      if (rec) { rec.stop(); return; }
      rec = new Rec(); rec.lang = "es-CO"; rec.interimResults = true;
      $("#mic").setAttribute("aria-pressed", "true");
      rec.onresult = (e) => { txt.value = [...e.results].map((r) => r[0].transcript).join(""); };
      rec.onend = () => { $("#mic").setAttribute("aria-pressed", "false"); rec = null; if (txt.value.trim()) $("#form").requestSubmit(); };
      rec.onerror = () => { $("#mic").setAttribute("aria-pressed", "false"); rec = null; };
      rec.start();
    });
  }
  function leerEnVoz(texto, forzar = false) {
    if (!("speechSynthesis" in window) || (!forzar && !$("#chkVoz").checked)) return;
    speechSynthesis.cancel();
    const u = new SpeechSynthesisUtterance(String(texto).replace(/[*_#>`]/g, ""));
    u.lang = "es-CO";
    const voz = speechSynthesis.getVoices().find((v) => v.lang.startsWith("es"));
    if (voz) u.voice = voz;
    speechSynthesis.speak(u);
  }

  const prefs = leer("prefs", { tam: "0", contraste: false, voz: false });
  function aplicarPrefs() {
    document.documentElement.dataset.tam = prefs.tam;
    document.documentElement.dataset.contraste = prefs.contraste ? "1" : "0";
    $$("[data-tam]", menu).forEach((b) => b.setAttribute("aria-pressed", String(b.dataset.tam === prefs.tam)));
    $("#chkContraste").checked = prefs.contraste;
    $("#chkVoz").checked = prefs.voz;
    guardar("prefs", prefs);
  }
  aplicarPrefs();
  menu.addEventListener("click", (e) => { const b = e.target.closest("[data-tam]"); if (b) { e.stopPropagation(); prefs.tam = b.dataset.tam; aplicarPrefs(); } });
  $("#chkContraste").addEventListener("change", (e) => { prefs.contraste = e.target.checked; aplicarPrefs(); });
  $("#chkVoz").addEventListener("change", (e) => { prefs.voz = e.target.checked; aplicarPrefs(); });
  $("#dlgFuente").addEventListener("click", (e) => { if (e.target === e.currentTarget) e.currentTarget.close(); });
  document.addEventListener("keydown", (e) => { if (e.key === "Escape") { if (!menu.hidden) cerrarMenu(); else if (WIDGET && !$("#dlgFuente").open) parent.postMessage("isa:cerrar", location.origin); } });

  // Mismo perfil y conversación entre el widget y la pantalla completa (misma página de origen).
  window.addEventListener("storage", (e) => {
    if (e.key === "isa.chat" && !$("#p-chat").hidden) { chat = leer("chat", []); pintarChat(); }
    if (e.key === "isa.perfil") { perfil = leer("perfil", null); pintarPerfil(); actualizarWa(); }
  });

  /* ---------------------------------------------------------------- arranque */
  fetch("api/chat").then((r) => (r.ok ? r.json() : {})).catch(() => ({})).then((j) => {
    if (!j.ia) activarModoLiteral();
    numeroWa = j.whatsapp || null;
    actualizarWa();
  });
  actualizarWa();
  if (WIDGET) ir(perfil ? "p-chat" : "p-perfil");
  else ir("p-inicio");
})();
