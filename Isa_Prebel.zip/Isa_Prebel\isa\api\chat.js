// POST /api/chat  (función de Vercel, runtime Node)
// Respuesta: NDJSON en streaming
//   {"t":"delta","v":"..."}                     texto a medida que Isa escribe
//   {"t":"fin", fuentes, sugerencias, valido, reemplazo}   cierre
//   {"t":"error","v":"..."}
import Anthropic from "@anthropic-ai/sdk";
import { responder, separarCierre, validar, etiquetasFuentes, respuestaLiteral, hayClave, NO_INFO } from "../lib/isa.js";

async function leerCuerpo(req) {
  if (req.body && typeof req.body === "object") return req.body;
  if (typeof req.body === "string") return JSON.parse(req.body || "{}");
  const partes = [];
  for await (const p of req) partes.push(p);
  return JSON.parse(Buffer.concat(partes).toString("utf8") || "{}");
}

export default async function handler(req, res) {
  if (req.method === "GET") {
    res.setHeader("content-type", "application/json");
    // whatsapp: número público de la línea de Isa (solo dígitos, con 57). Vacío = "próximamente".
    return res.end(JSON.stringify({ ok: true, ia: hayClave(), whatsapp: (process.env.ISA_WHATSAPP_NUMERO || "").replace(/\D/g, "") || null }));
  }
  if (req.method !== "POST") {
    res.statusCode = 405;
    return res.end();
  }

  let cuerpo;
  try {
    cuerpo = await leerCuerpo(req);
  } catch {
    res.statusCode = 400;
    return res.end(JSON.stringify({ error: "json_invalido" }));
  }
  const pregunta = String(cuerpo.pregunta || "").trim();
  if (!pregunta) {
    res.statusCode = 400;
    return res.end(JSON.stringify({ error: "pregunta_vacia" }));
  }
  if (!hayClave()) {
    // Sin API key la web cambia al motor literal de Valentina (modo sin conexión).
    res.statusCode = 503;
    res.setHeader("content-type", "application/json");
    return res.end(JSON.stringify({ error: "sin_clave" }));
  }

  res.statusCode = 200;
  res.setHeader("content-type", "application/x-ndjson; charset=utf-8");
  res.setHeader("cache-control", "no-store");
  const enviar = (o) => res.write(JSON.stringify(o) + "\n");

  try {
    const r = await responder(
      { historial: Array.isArray(cuerpo.historial) ? cuerpo.historial : [], pregunta, perfil: cuerpo.perfil || {} },
      (v) => enviar({ t: "delta", v }),
    );
    if (r.rechazo) {
      enviar({ t: "fin", fuentes: [], sugerencias: [], valido: false, reemplazo: `${NO_INFO}\n\nSi lo prefieres, toca **Hablar con una persona** y te comparto el contacto de Gestión Humana.` });
      return res.end();
    }
    const { texto, fuentes, sugerencias } = separarCierre(r.bruto);
    const v = validar(texto, fuentes);
    if (!v.valido) console.warn("[isa] respuesta sin respaldo, se reemplaza por texto literal", v);
    enviar({
      t: "fin",
      fuentes: etiquetasFuentes(fuentes),
      sugerencias,
      valido: v.valido,
      reemplazo: v.valido ? null : respuestaLiteral(fuentes),
      texto,
    });
    console.log(`[isa] ${r.modelo} in=${r.uso?.input_tokens} cache_read=${r.uso?.cache_read_input_tokens} cache_write=${r.uso?.cache_creation_input_tokens} out=${r.uso?.output_tokens}`);
  } catch (err) {
    let v = "No pude responder en este momento. Intenta de nuevo en unos segundos.";
    if (err instanceof Anthropic.AuthenticationError) v = "La clave de IA no es válida. Avisa al equipo del proyecto.";
    else if (err instanceof Anthropic.RateLimitError) v = "Estoy recibiendo muchas preguntas. Intenta de nuevo en un momento.";
    else if (err instanceof Anthropic.APIError) console.error("[isa] API", err.status, err.message);
    else console.error("[isa]", err);
    enviar({ t: "error", v });
  }
  res.end();
}
