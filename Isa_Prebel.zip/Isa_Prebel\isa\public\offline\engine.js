/* Motor local (modo demo sin servidor). Réplica del motor Python: responde SOLO con
   el texto literal de los documentos oficiales; si no hay coincidencia con el tema -> "no disponible". */
(function () {
  const D = window.KB_DATA;
  const STOP = new Set(D.stop), SYN = D.synonyms, GENERIC = new Set(D.generic);
  const NO_INFO = "Lo siento, esa información no está disponible en este momento, ya que mi conocimiento se limita únicamente a los documentos oficiales de Gestión Humana.\n\nPuedes escribir *menú* para ver los temas disponibles o *asesor* para ver los contactos de Gestión Humana.";
  const DISCLAIMER = "_Asistente de Gestión Humana con inteligencia artificial: puede cometer errores. Valida la información con Stefanny Pulgarín (Analista de Bienestar y RSE) o Michell Román (Asistente Gestión Humana)._";
  const MENU = D.menu;
  const GROUP_RE = /personal|perteneces|n[oó]mina|operativ|administrativ|impul?s|mercad/i;
  const GROUP_PAT = { operativo: /operativ/i, administrativo: /administrativ/i, impulso: /impul?s|mercad/i };

  const strip = s => s.normalize("NFD").replace(/[̀-ͯ]/g, "");
  function stem(w) {
    if (w.length > 6 && /(ar|er|ir)$/.test(w)) w = w.slice(0, -2);
    for (const suf of ["ciones", "cion", "mente", "es", "as", "os", "s", "a", "o", "e"])
      if (w.length > 4 && w.endsWith(suf)) return w.slice(0, -suf.length);
    return w;
  }
  function tokens(text, expand = false, strongOnly = false) {
    const out = [];
    for (const w of strip(text.toLowerCase()).match(/[a-z0-9ñ]+/g) || []) {
      if (STOP.has(w) || w.length < 2) continue;
      out.push(stem(w));
      if (expand) for (const x of SYN[w] || []) if (!(strongOnly && GENERIC.has(x))) out.push(stem(x));
    }
    return out;
  }
  // índice
  const S = D.sections;
  const df = {};
  for (const s of S) {
    s.tt = tokens(s.path.slice(1).join(" ") || s.doc_title);
    s.bt = tokens(s.body);
    s.tf = {}; s.bt.forEach(t => s.tf[t] = (s.tf[t] || 0) + 1);
    s.ttf = new Set(s.tt);
    new Set([...s.tt, ...s.bt]).forEach(t => df[t] = (df[t] || 0) + 1);
  }
  const N = S.length, avg = S.reduce((a, s) => a + s.bt.length, 0) / N;
  const idf = {}; for (const t in df) idf[t] = Math.log(1 + (N - df[t] + 0.5) / (df[t] + 0.5));
  const key2 = s => s.path.slice(0, 2).join("›");
  const family = sec => S.filter(s => s.doc === sec.doc && key2(s) === key2(sec));

  function search(q, grupo, k = 8) {
    const qt = [...new Set(tokens(q, true))]; const res = [];
    for (const s of S) {
      let sc = 0; const m = new Set(); const dl = s.bt.length || 1;
      for (const t of qt) {
        const i = idf[t]; if (!i) continue;
        const f = s.tf[t] || 0;
        if (f) { sc += i * f * 2.4 / (f + 1.4 * (0.25 + 0.75 * dl / avg)); m.add(t); }
        if (s.ttf.has(t)) { sc += 2.2 * i; m.add(t); }
      }
      if (grupo && sc && GROUP_PAT[grupo].test(s.path.join(" "))) sc *= 1.25;
      if (sc > 0) res.push([sc, s, m]);
    }
    return res.sort((a, b) => b[0] - a[0]).slice(0, k);
  }

  const ses = { options: [], grupo: null };
  const answer = (text, status, extra = {}) => Object.assign({ texto: text, estado: status, opciones: [], fuentes: [] }, extra);

  function menu() {
    ses.options = MENU.map((_, i) => "__menu__" + i);
    let t = "¡Hola! 👋 Soy el asistente de *Gestión Humana de Prebel*. ¿Sobre qué tema quieres consultar?\n\n";
    t += MENU.map((m, i) => `*${i + 1}.* ${m[0]} — ${m[1]}`).join("\n");
    t += "\n\nEscribe tu pregunta, usa el *micrófono* o elige un tema.\n_Recuerda: respondo únicamente con base en los documentos oficiales de Gestión Humana._";
    return answer(t, "menu", { opciones: MENU.map(m => m[0]) });
  }
  function options(secs, header) {
    ses.options = secs.map(s => s.id);
    const labels = secs.map(s => s.path[1] || s.path[0]);
    return answer(header + "\n\n" + labels.map((l, i) => `*${i + 1}.* ${l === l.toUpperCase() ? l[0] + l.slice(1).toLowerCase() : l}`).join("\n") + "\n\nElige una opción o escribe tu pregunta con más detalle.", "ambiguous", { opciones: labels });
  }
  function expandKids(sec) {
    const out = [sec];
    if (sec.path.length === 2) {
      const fam = family(sec);
      let kids = fam.filter(s => s.path.length === 3 && s.body.length < 450 && !s.path[2].startsWith("¿"));
      if (fam.length > 7) kids = kids.filter(k => GROUP_RE.test(k.path[2]));
      if (ses.grupo) {
        const grp = kids.filter(k => GROUP_RE.test(k.path[2]));
        const mine = grp.filter(k => GROUP_PAT[ses.grupo].test(k.path[2]));
        if (mine.length) kids = kids.filter(k => !grp.includes(k) || mine.includes(k));
      }
      out.push(...kids);
    }
    return out;
  }
  function compose(secs, expand = true) {
    ses.options = [];
    const blocks = [], src = [], seen = new Set(); let otherAt = null;
    secs.forEach((s, i) => {
      const parts = expand && i === 0 ? expandKids(s) : [s];
      if (i > 0 && s.doc !== secs[0].doc && otherAt === null) otherAt = blocks.length;
      for (const p of parts) {
        if (seen.has(p.id)) continue; seen.add(p.id);
        const title = p.path.slice(1).join(" › ") || p.doc_title;
        blocks.push(`*${title}*\n${p.body}`);
        const sname = `${p.doc} → ${p.path.slice(1, 2).join("") || p.doc_title}`;
        if (!src.includes(sname)) src.push(sname);
      }
    });
    if (otherAt !== null) blocks.splice(otherAt, 0, "—\n_También encontré esto en otro documento oficial (revisa ambos; si ves diferencias, confírmalo con Gestión Humana):_");
    const body = blocks.join("\n\n");
    return answer(`¡Claro! Esto es lo que necesitas saber:\n\n${body}\n\n📄 _Fuente: ${src.join("; ")}_\n\nSi necesitas más detalles, aquí estoy para ayudarte.\n\n${DISCLAIMER}`, "ok", { fuentes: src, voz: body });
  }
  function category(prefix) {
    const seen = new Set(), opts = [];
    for (const s of S) if (s.doc_title.toLowerCase().startsWith(prefix.toLowerCase().slice(0, 8))) {
      const mj = s.path[1] || s.doc_title; if (!seen.has(mj)) { seen.add(mj); opts.push(s); }
    }
    return options(opts.slice(0, 10), `Estos son los temas de *${prefix}*:`);
  }
  function bySection(id) {
    const sec = S.find(s => s.id === id); if (!sec) return answer(NO_INFO, "no_info");
    const fam = family(sec);
    if (fam.filter(s => s.path.length === 3 && s.path[2].startsWith("¿")).length >= 3) {
      const f = fam.slice(0, 12); ses.options = f.map(s => "__direct__" + s.id);
      return answer(`Sobre *${sec.path[1]}*, ¿qué quieres saber?\n\n` + f.map((s, i) => `*${i + 1}.* ${s.path[2] || "Información general"}`).join("\n"), "ambiguous", { opciones: f.map(s => s.path[2] || "Información general") });
    }
    return compose([sec]);
  }
  const human = () => answer(D.human, "human");

  function ask(msg, grupo) {
    msg = (msg || "").trim(); if (grupo !== undefined) ses.grupo = grupo || null;
    let a = respond(msg);
    if (/\b\d[\d .-]{5,}\d\b/.test(msg) || /diagn[oó]stico|historia cl[ií]nica|mi salario es/i.test(msg))
      a.aviso = "Por tu seguridad, no compartas por este chat números de documento, datos de salud ni información personal. Esos datos solo se entregan a la persona encargada de Gestión Humana.";
    return a;
  }
  function respond(msg) {
    if (!msg || /^\s*(hola|buen[oa]s?( dias| días| tardes| noches)?|hey|menu|menú|inicio|ayuda|0)\W*$/i.test(msg)) return menu();
    if (/^\s*(gracias|muchas gracias|ok|listo|perfecto|vale|dale)\W*$/i.test(msg)) return answer("¡Con gusto! Si necesitas más detalles, aquí estoy para ayudarte.", "thanks");
    if (/(hablar|comunicar|contactar).{0,20}(persona|humano|alguien|asesor)|^\s*asesor\s*$/i.test(msg)) return human();
    const m = msg.match(/^\s*(\d{1,2})\s*[.)]?\s*$/);
    if (m && !ses.options.length) ses.options = MENU.map((_, i) => "__menu__" + i);
    if (m) {
      const c = ses.options[+m[1] - 1];
      if (c) {
        if (c.startsWith("__menu__")) { const i = +c.slice(8); return i === 4 ? human() : category(D.menu_cats[i]); }
        if (c.startsWith("__direct__")) return compose([S.find(s => s.id === c.slice(10))]);
        return bySection(c);
      }
    }
    const q = tokens(msg), hits = search(msg, ses.grupo);
    if (!hits.length || !q.length) return answer(NO_INFO, "no_info");
    const [top_score, top, matched] = hits[0];
    const qset = new Set(tokens(msg, true));
    const uq = new Set(q);
    const cov = [...matched].filter(t => qset.has(t)).length / Math.max(uq.size, 1);
    const strong = new Set(tokens(msg, true, true)); strong.delete("auxili");
    const titleHit = top.tt.some(t => strong.has(t)) || (uq.has("auxili") && top.ttf.has("auxili") && uq.size === 1);
    if (top_score < D.min_score || cov < D.min_cov || !(titleHit || cov >= 0.8)) {
      const broad = ["auxili", "credit", "licenci", "benefici", "certific"].filter(t => uq.has(t));
      if (broad.length) {
        const opts = [];
        for (const s of S) if (s.tt.slice(0, 4).some(t => broad.includes(t)) && opts.every(o => key2(o) !== key2(s))) opts.push(s);
        if (opts.length) return options(opts.slice(0, 12), "¿Sobre cuál de estos temas quieres saber?");
      }
      return answer(NO_INFO, "no_info");
    }
    if (uq.size === 1) {
      const opts = [];
      for (const [sc, s] of hits) if (sc >= top_score * 0.6 && opts.every(o => key2(o) !== key2(s))) opts.push(s);
      if (opts.length >= 3) return options(opts.slice(0, 6), "Tengo información sobre varios temas relacionados. ¿Cuál te interesa?");
    }
    if (top.path.length === 3 && GROUP_RE.test(top.path[2])) {
      let sibs = family(top).filter(s => s.path.length === 3 && GROUP_RE.test(s.path[2]));
      if (ses.grupo) { const f = sibs.filter(s => GROUP_PAT[ses.grupo].test(s.path[2])); sibs = f.length ? f : [top]; }
      const parent = family(top).filter(s => s.path.length === 2).slice(0, 1);
      return compose([...parent, ...sibs], false);
    }
    const chosen = [top];
    for (const [sc, s] of hits.slice(1, 4))
      if (s.doc !== top.doc && sc >= top_score * 0.8 && s.tt.some(t => top.ttf.has(t))) { chosen.push(s); break; }
    return compose(chosen);
  }
  window.LocalEngine = { ask, menu, count: N };
})();
