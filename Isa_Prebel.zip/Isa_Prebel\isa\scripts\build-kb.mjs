// Genera la base de conocimiento de Isa a partir de las secciones que Valentina ya
// dejó parseadas (data/kb_data_valentina.js): tablas unidas, versión más reciente, glosario incluido.
// Salidas:
//   lib/knowledge.js            -> texto que recibe Claude + índice de secciones (servidor)
//   public/fuentes.json         -> id, etiqueta y texto literal de cada sección (chips de fuente en la web)
//   conocimiento/base_conocimiento_isa.md -> versión legible para revisión de Gestión Humana
import fs from "node:fs";
import path from "node:path";
import vm from "node:vm";
import { fileURLToPath } from "node:url";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const sandbox = { window: {} };
vm.runInNewContext(fs.readFileSync(path.join(root, "data/kb_data_valentina.js"), "utf8"), sandbox);
const sections = sandbox.window.KB_DATA.sections;

const DOCS = {
  "Vinculacion_y_nomina_20260310.md": { pre: "VIN", nombre: "Vinculación y nómina", fecha: "10/03/2026" },
  "Creditos_Prebel_20260310.md": { pre: "CRE", nombre: "Créditos Prebel", fecha: "10/03/2026" },
  "Auxilios_y_beneficios_Prebel_20260310.md": { pre: "AUX", nombre: "Auxilios y beneficios", fecha: "10/03/2026" },
  "Glosario_Business_Partner_20260922.md": { pre: "GLO", nombre: "Glosario Business Partner", fecha: "22/09/2026" },
};

const tidy = (t) => (t === t.toUpperCase() && /[A-ZÁÉÍÓÚ]{4}/.test(t) ? t[0] + t.slice(1).toLowerCase() : t);
const counters = {};
const index = [];
for (const s of sections) {
  const d = DOCS[s.doc];
  if (!d) throw new Error("Documento sin prefijo: " + s.doc);
  counters[d.pre] = (counters[d.pre] || 0) + 1;
  const id = `${d.pre}-${String(counters[d.pre]).padStart(2, "0")}`;
  const ruta = s.path.slice(1).map(tidy);
  index.push({
    id,
    doc: d.nombre,
    archivo: s.doc,
    fecha: d.fecha,
    ruta,
    etiqueta: `${d.nombre} › ${ruta.join(" › ") || d.nombre}`,
    texto: s.body.trim(),
  });
}

// Texto para Claude: un bloque por documento, una sección por id.
let kb = "";
for (const [archivo, d] of Object.entries(DOCS)) {
  kb += `\n<documento nombre="${d.nombre}" archivo="${archivo}" fecha="${d.fecha}">\n`;
  for (const s of index.filter((x) => x.archivo === archivo)) {
    kb += `\n[${s.id}] ${s.ruta.join(" › ") || d.nombre}\n${s.texto}\n`;
  }
  kb += `</documento>\n`;
}

const out = `// ARCHIVO GENERADO por scripts/build-kb.mjs. No editar a mano.
export const KB_TEXT = ${JSON.stringify(kb.trim())};
export const SECCIONES = ${JSON.stringify(index.map(({ texto, ...r }) => ({ ...r, texto })))};
`;
fs.writeFileSync(path.join(root, "lib/knowledge.js"), out);
fs.writeFileSync(
  path.join(root, "public/fuentes.json"),
  JSON.stringify(Object.fromEntries(index.map((s) => [s.id, { etiqueta: s.etiqueta, fecha: s.fecha, texto: s.texto }]))),
);

let md = `# Base de conocimiento de Isa\n\nGenerada desde los documentos oficiales de Gestión Humana (secciones parseadas por Valentina). ${index.length} secciones con identificador para citar.\n`;
for (const [archivo, d] of Object.entries(DOCS)) {
  md += `\n## ${d.nombre} (${archivo}, ${d.fecha})\n`;
  for (const s of index.filter((x) => x.archivo === archivo)) md += `\n### [${s.id}] ${s.ruta.join(" › ")}\n\n${s.texto}\n`;
}
fs.writeFileSync(path.join(root, "conocimiento/base_conocimiento_isa.md"), md);

console.log(`Secciones: ${index.length}`, counters, `| caracteres KB: ${kb.length}`);
