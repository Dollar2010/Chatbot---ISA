// Prueba local del endpoint /api/chat sin navegador.
// Uso: node scripts/check.mjs "pregunta" [tipo] [sede]
import { PassThrough } from "node:stream";
const { default: handler } = await import("../api/chat.js");
const pregunta = process.argv[2] || "¿Cómo pido mi certificado laboral?";
const req = new PassThrough();
req.method = "POST";
req.end(JSON.stringify({ pregunta, perfil: { tipo: process.argv[3] || "operativo", sede: process.argv[4] || "productora" }, historial: [] }));
let salida = "";
const res = { statusCode: 200, headers: {}, setHeader(k, v) { this.headers[k] = v; }, write(c) { salida += c; }, end(c) { if (c) salida += c; console.log("HTTP", this.statusCode); const lineas = salida.trim().split("\n"); const deltas = lineas.filter(l => l.includes('"t":"delta"')).length; console.log("deltas:", deltas); lineas.filter(l => !l.includes('"t":"delta"')).forEach(l => console.log(l)); } };
await handler(req, res);
