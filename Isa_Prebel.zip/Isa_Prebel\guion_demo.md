# Guion de demo · Isa (3 minutos)

**Mensaje central:** Isa vive donde ya está el colaborador (intranet, sitio web y WhatsApp), le da **su** respuesta en pocas líneas y le muestra de dónde sale.

| Tiempo | Qué se muestra | Qué se dice |
|---|---|---|
| 0:00 | Intranet de Prebel (demo) con la burbuja de Isa | "Isa no es otra página: aparece dentro de la intranet, como cualquier chat de soporte." |
| 0:15 | Abrir el widget → perfil en dos toques | "Operativo, Sede Productora. Sin datos personales. Con eso Isa sabe qué trámite y qué persona te corresponden." |
| 0:35 | Tarjeta Nómina → "¿Cómo pido mi certificado laboral?" | "Respuesta corta, con el contacto exacto de Angela Quintero." |
| 0:55 | Tocar la fuente | "Cada respuesta trae su fuente: el texto oficial y la fecha del documento." |
| 1:10 | Menú → cambiar a Administrativo y repetir | "Misma pregunta, otra respuesta correcta: Prebelnet." |
| 1:30 | "¿Cuántos días tengo para entregar una incapacidad?" | "Dos documentos dicen 3 y 5 días. Isa no elige: muestra ambas fuentes. Hallazgo para Gestión Humana." |
| 1:50 | "¿Cuál es el salario mínimo?" | "Si no está en los documentos, no lo inventa." |
| 2:00 | Botón ⤢ → pantalla completa (inicio con "Así funciona") | "Quien quiera más espacio lo abre en grande. La conversación se conserva." |
| 2:15 | Botón "Por WhatsApp" + diagrama | "El mismo cerebro responde por WhatsApp. El botón abre el chat con el perfil incluido; Isa no vuelve a preguntar." |
| 2:40 | Menú → Salir y borrar mis datos | "Y el colaborador controla sus datos: un toque y se borra todo del dispositivo." |

**Plan B:** si falla la IA, Isa pasa sola al motor literal de Valentina y sigue respondiendo con el texto oficial.
