# Plan · Isa, asistente de Gestión Humana de Prebel

EstudIA · Reto 7 · Versión 2 para revisión (21/11/2026)

---

## 0. Decisiones tomadas

| Tema | Decisión |
|---|---|
| Nombre | **Isa** (Isabel). Lleva el "bel" de Pre**bel** |
| Motor de IA | **Claude** (cuenta de Santiago) |
| Publicación | **Vercel**, con enlace público |
| Documentos | Los 5 .md de marzo y septiembre 2026 se toman como datos de referencia vigentes |
| WhatsApp | Se diseña la conexión ahora y queda lista para conectar después |
| Logo | Santiago lo consigue y lo agrega a `Contexto/` |
| Entregables | Todo en `Salida/` |

---

## 1. Lectura del reto

**Problema real:** los +1.200 empleados (operativos, impulso y mercado, administrativos, en 3 sedes) no saben a quién acudir ni qué requisitos cumplir en sus trámites de Gestión Humana. Hoy hay un GPT público en ChatGPT que no vive donde está la gente (WhatsApp) y no tiene identidad propia.

**Acuerdos de la sesión de contexto (Granola):** bot que responde solo con los documentos y sin inventar, **fuente en cada respuesta**, mínimo 5 pruebas verificadas, diagrama de conexión a WhatsApp, interfaz con marca Prebel y publicación en Vercel. Riesgos abiertos: autenticación, privacidad, accesibilidad (conductores, discapacidad visual o auditiva), quién actualiza el contenido y costos de Meta.

**Dónde está el valor:** que el bot responda ya lo hace el GPT actual. Lo diferencial es:
1. **Responder según quién pregunta** (tipo de personal y sede cambian la respuesta y el contacto).
2. **Una llegada con identidad**, no un cuadro de chat vacío.
3. **Trazabilidad:** fuente en cada respuesta y paso directo a la persona correcta.

---

## 2. Lo que ya construyó Valentina (`Contexto/asistente-gh-prebel/prebel-gh-bot`)

Es un trabajo técnico sólido y muy completo. Resumen:

| Pieza | Qué hace |
|---|---|
| Motor "cero alucinación" | **No usa IA para redactar.** Busca la sección más parecida (BM25 + sinónimos) y devuelve el texto literal con su fuente. Si no encuentra, dice "no disponible" |
| Validador | Si se activa un LLM, descarta cualquier cifra, correo o teléfono que no exista en la fuente |
| Perfil | Pregunta "¿A qué nómina perteneces?" (operativa, administrativa, impulso y mercado, no sé) |
| Autenticación | Celular contra el directorio de nómina + código por WhatsApp + sesión de 8 h |
| WhatsApp | Webhook de Meta Cloud API, listas interactivas, notas de voz, cola de trabajo, límite por persona |
| Privacidad | Enmascara cédulas, teléfonos y correos; retención de 30 días; advierte si compartes datos sensibles |
| Contenido | Sincroniza los documentos desde una carpeta de Google Drive cada 30 min |
| Accesibilidad | Micrófono, lectura en voz alta, letra grande, alto contraste, teclado |
| Demo | `Asistente_GH_Prebel_demo.html`, funciona sin internet |
| Stack | Python (Starlette) + Docker, pensado para el **servidor on-premise** de Prebel |

**Hallazgos valiosos de su revisión (los adoptamos):**
- **Incapacidades:** un documento dice 3 días hábiles y otro dice 5. Isa debe mostrar ambas con su fuente hasta que Gestión Humana lo unifique.
- Códigos sin explicar (PA, PO, PI, PP), errores tipográficos ("Impuso y mercado"), tablas partidas.
- El GPT actual solo conocía 3 archivos; el Glosario también entra.

**Lo que le falta (y es justo nuestro aporte):**

| Brecha | Detalle |
|---|---|
| Marca | Colores aproximados (`#14225A`, `#1A9C9A`), no los del manual. Sin Acid Grotesk |
| Identidad | Se llama "Asistente de Gestión Humana", sin nombre ni personalidad |
| Llegada | Celular → código → nómina → chat. Funciona como control de acceso, pero no es una experiencia |
| Conversación | Al ser extractivo, responde con bloques literales de documento: exacto, pero largo y poco conversacional |
| Vercel | Su servidor usa procesos en segundo plano (cola, sincronización de Drive). No encaja en Vercel; encaja en el servidor on-premise |

**Conclusión:** no competimos con su versión, la complementamos. Su servidor es el **camino a producción** (WhatsApp, on-premise, seguridad). Isa es la **cara y la voz**: la experiencia, la marca y una conversación natural con Claude, protegida con su misma regla de cero alucinación.

---

## 3. Manual de marca

| Elemento | Valor |
|---|---|
| Color principal | **Azul Prebel `#40647E`** (debe dominar) |
| Principales | `#E3DED8` arena · `#55606B` gris texto · `#F2917E` coral · `#60A491` verde |
| Complementarios | `#768FC2` azul · `#A6CAEC` / `#8DC7E8` celeste · `#5B7F71` verde oscuro · `#5C653A` oliva · `#DAD9C9` neutro |
| Tipografía | Acid Grotesk (los .otf están en `Contexto/`). Respaldo: Roboto / Arial |
| Jerarquía | Títulos 24 px Bold · Subtítulos 20 px Bold · Texto 16 px Regular |
| Lenguaje visual | Fondos azul oscuro, botones tipo píldora en coral, tipografía grande y liviana, símbolo de cuatro puntos del logo |
| Tono | "The beauty and personal care partner", empresa BIC / B Corp, "Brand Lovers" |

---

## 4. Experiencia de llegada de Isa

Que entrar se sienta como llegar a la recepción de Gestión Humana.

```
 1. LLEGADA          2. ¿QUIÉN ERES?        3. ACUERDO            4. TEMAS              5. CONVERSACIÓN         6. CIERRE
 Fondo azul          "¿Cómo trabajas        Qué puedo y qué       Tarjetas:             Respuesta de Isa       "¿Te sirvió?"
 Prebel. Isa se      en Prebel?"            no puedo hacer.       · Vinculación         + chip de fuente       👍 / 👎
 presenta con        · Operativo            "Funciono con IA,       y nómina            + "Hablar con          Contacto directo
 saludo según        · Impulso y mercado    puedo equivocarme"    · Créditos            una persona"           de quien atiende
 la hora             · Administrativo       [Entendido]           · Auxilios            (contacto según
                     · No sé                                      · Tu BP y glosario    tipo y sede)
                     "¿En qué sede?"                              + escribir o 🎤
```

- **Saludo:** "Buenos días. Soy Isa, de Gestión Humana. Te ayudo con trámites, créditos y beneficios."
- **Perfil sin login:** tipo de personal + sede se recuerdan en el navegador y personalizan las respuestas. Se reutiliza la taxonomía de Valentina.
- **Accesibilidad:** se reutilizan sus controles (micrófono, voz alta, letra grande, alto contraste).
- **Preguntas sugeridas** por tema, para quien no sabe qué preguntar.
- **Puente a WhatsApp:** botón y QR "Escríbele a Isa por WhatsApp" (mostrado como "próximamente" hasta conectar la línea).
- **En WhatsApp** la misma secuencia con mensajes de lista y botones (ya los implementa el código de Valentina).

---

## 5. Arquitectura

**Decisión clave:** los 5 documentos suman ~82 KB (~25 mil tokens). No hace falta base vectorial: Claude recibe los documentos completos en cada consulta, con **caché de prompt** para que sea rápido y barato.

```
 HOY (MVP en Vercel)
 Empleado ──► Web de Isa (Vercel) ──► /api/chat (servidor Vercel) ──► Claude
              llegada + chat           · prompt de Isa                  │
                                       · 5 documentos (en caché)        ▼
                                       · perfil (tipo + sede)       Validador "cero alucinación"
                                       · API key oculta             (cifras, correos y teléfonos
                                                                     deben existir en la fuente;
                                                                     si no, se responde con el
                                                                     texto literal: idea de Valentina)

 DESPUÉS (WhatsApp, producción)
 Empleado ──► WhatsApp ──► Meta Cloud API ──► Servidor on-premise Prebel (código de Valentina:
                                              webhook, verificación del número, privacidad, cola)
                                                          │
                                                          ▼
                                              Mismo cerebro de Isa (prompt + Claude + validador)
```

- **Front:** Next.js con la marca de Prebel (Acid Grotesk embebida, paleta oficial).
- **Cerebro:** SDK oficial de Anthropic en TypeScript, respuesta en streaming (se ve escribir a Isa).
- **Fuentes:** cada sección de los .md lleva un identificador; Isa cita `Documento → Sección` y la web lo muestra como chip.
- **Seguridad:** la API key vive en las variables de entorno de Vercel, nunca en el navegador. Sin datos personales en el MVP.

### Sobre la cuenta de Claude (importante)

La suscripción de claude.ai (Pro o Max) **no incluye acceso a la API**. Para el MVP hace falta una **API key** en `console.anthropic.com`, que se factura aparte con créditos prepagados.

| Modelo | Costo aproximado por pregunta* | Comentario |
|---|---|---|
| Claude Opus 5.5 (por defecto) | ~1,5 centavos de dólar | La mejor calidad. 100 preguntas de demo ≈ 1,5 USD |
| Claude Haiku 5.5 | < 0,1 centavos | Muy barato y rápido; buena opción para 1.200 empleados en producción |

*Estimado con los documentos en caché (~25 mil tokens leídos) y ~500 tokens de respuesta. Se mide en las pruebas.

---

## 6. Plan de trabajo y entregables (todo en `Salida/`)

| # | Fase | Qué se hace | Entregable |
|---|---|---|---|
| 0 | Base de conocimiento | Partir de los `kb/` de Valentina, unir tablas partidas, poner ID a cada sección, mapa "quién atiende qué" por tipo y sede, marcar el conflicto de incapacidades | `Salida/isa/conocimiento/*.md` |
| 1 | Prompt de Isa | Personalidad, tono (basado en las instrucciones actuales), 5 documentos, fuente obligatoria, personalización, escalamiento, conflictos de datos | `Salida/isa/prompt_isa.md` |
| 2 | Cerebro | `/api/chat` con Claude + caché + streaming + validador portado de Valentina | código en `Salida/isa/` |
| 3 | Banco de pruebas | 12 preguntas: 5 obligatorias + fuera de alcance, ambigua, distinta por tipo de personal, trampa, tema delicado, conflicto de incapacidades. Esperado vs obtenido | `Salida/pruebas_isa.md` |
| 4 | Llegada + chat | Las 6 pantallas, marca Prebel, accesibilidad, móvil primero | web funcional |
| 5 | Diagrama WhatsApp | Flujo de la sección 5, requisitos de Meta (los que ya documentó Valentina), costos, on-premise vs nube | `Salida/diagrama_whatsapp.html` |
| 6 | Publicación y demo | Vercel, guion de demo de 3 minutos, siguientes pasos | URL pública + `Salida/guion_demo.md` |

Orden: 0 → 1 → 2 → 3 (aquí ya se cumple el mínimo del día) → 4 → 5 → 6.

---

## 7. Riesgos

| Riesgo | Mitigación |
|---|---|
| Isa inventa | Prompt estricto + fuente obligatoria + validador de Valentina + pruebas trampa |
| Respuesta para otro tipo de personal | Perfil en la llegada + regla en el prompt |
| Datos contradictorios (incapacidades) | Mostrar ambas fuentes y pedir confirmar con GH |
| Información desactualizada | Fecha visible por documento; la sincronización con Drive de Valentina en producción |
| Datos sensibles | MVP sin datos personales; temas delicados van a contacto humano |
| Costo de la API | Caché de prompt; Haiku 5.5 como opción para producción |

---

## 8. Lo que necesito para arrancar

1. **API key de Claude** creada en `console.anthropic.com` con créditos (5 USD alcanzan para toda la demo). No la pegues en el chat: la cargamos como variable de entorno en Vercel y en un `.env.local`.
2. **Logo de Prebel:** idealmente SVG; si no, PNG con fondo transparente, en versión a color y en blanco (para fondos azules).
3. **Cuenta de Vercel** con sesión iniciada (o la CLI de Vercel), para publicar.
4. **Confirmar con Valentina** que reutilizamos sus `kb/`, su validador y su taxonomía, y que su servidor queda como el camino a WhatsApp.
