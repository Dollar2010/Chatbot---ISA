# Isa · Asistente de Gestión Humana de Prebel (MVP)

EstudIA · Reto 7. Web con experiencia de llegada + chat, con la marca de Prebel, respondida por Claude con los documentos oficiales de Gestión Humana.

## Cómo funciona

```
public/
  index.html       demo de intranet con Isa como widget lateral (el <script> del final es el snippet de integración)
  isa.html         Isa en pantalla completa: inicio + "así funciona" → perfil → chat
                   isa.html?vista=widget es la versión compacta que carga el widget
  offline/         motor literal de Valentina (respaldo automático si no hay IA)
  fuentes.json     texto oficial de cada sección (se abre al tocar una fuente)
api/chat.js        canal web: recibe la pregunta y responde en streaming
api/whatsapp.js    canal WhatsApp: webhook de Meta → mismo cerebro
lib/estado.js      memoria de WhatsApp (Upstash Redis opcional; si no, memoria del proceso)
lib/canal-whatsapp.js  envío de textos, botones y listas por la API de Meta
lib/prompt_isa.md  personalidad y reglas de Isa (editable por el equipo)
lib/isa.js         cerebro: prompt + documentos en caché + Claude + validador
lib/knowledge.js   116 secciones con ID (generado por scripts/build-kb.mjs)
conocimiento/      la misma base en Markdown, para revisión de Gestión Humana
scripts/           dev (servidor local), probar (banco de pruebas), check, build-kb
```

- **Modelo:** `claude-opus-5-5` con esfuerzo `low` (rápido y suficiente para chat). Se cambia con `ISA_MODEL` y `ISA_EFFORT`.
- **Caché de prompt:** el prompt y los documentos (~25 mil tokens) se cachean; cada pregunta paga solo la lectura de caché.
- **Respaldo ante rechazos:** activo el parámetro `fallbacks: "default"` de la API. Si un filtro de seguridad declina por error una pregunta, otro modelo la responde. Se desactiva con `ISA_FALLBACKS=0`.
- **Validador cero alucinación** (regla del motor de Valentina): toda cifra, porcentaje, correo o teléfono de la respuesta debe existir en los documentos. Si no, Isa muestra el texto oficial.
- **Sin API key** la web sigue funcionando con el motor literal de Valentina y lo avisa en pantalla.

## Correr local

```powershell
cd Salida\isa
npm install
Copy-Item .env.example .env.local   # y pega tu ANTHROPIC_API_KEY en .env.local
npm run dev                          # http://localhost:5173
npm run probar                       # 12 pruebas → Salida/pruebas_isa.md
```

La API key se crea en `console.anthropic.com` (se factura aparte de la suscripción de claude.ai).

## Publicar en Vercel

```powershell
cd Salida\isa
npx vercel login
npx vercel link
npx vercel env add ANTHROPIC_API_KEY production
npx vercel --prod
```

Vercel instala las dependencias, sirve `public/` y crea las funciones `api/chat` y `api/whatsapp`.

## Integrar en la intranet o el sitio web

Copiar el bloque `isa-lanzador` / `isa-panel`, sus estilos y el `<script>` final de `public/index.html`, cambiando `isa.html` por la URL pública de Isa. El widget y la pantalla completa comparten perfil y conversación cuando están en el mismo dominio.

## Activar WhatsApp

Ver `Salida/diagrama_whatsapp.html`. En resumen: crear la app y la línea en Meta, cargar `WA_TOKEN`, `WA_PHONE_NUMBER_ID`, `WA_APP_SECRET`, `WA_VERIFY_TOKEN` e `ISA_WHATSAPP_NUMERO` en Vercel, registrar el webhook `https://<dominio>/api/whatsapp` y agregar Upstash Redis para la memoria.

## Cambiar contenido

1. Actualizar los documentos en `Contexto/` (o en el repositorio de Valentina) y regenerar `data/kb_data_valentina.js` con su script `exportar_web.py`.
2. `npm run kb` regenera `lib/knowledge.js`, `public/fuentes.json` y `conocimiento/`.
3. `npm run probar` para verificar y volver a publicar.

## Créditos

Base de conocimiento parseada, motor literal, validador y servidor de WhatsApp: Valentina. Experiencia, marca, prompt de Isa e integración con Claude: Santiago.
